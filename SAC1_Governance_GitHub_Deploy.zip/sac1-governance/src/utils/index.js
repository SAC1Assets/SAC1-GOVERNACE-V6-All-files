/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { format, formatDistanceToNow } from 'date-fns'
import { GOVERNANCE_TIERS } from '@/constants'

// ─── FORMATTING ───────────────────────────────────────────────────────────────
export const fmtCurrency = (n, decimals = 0) => {
  if (n >= 1e9)  return `$${(n / 1e9).toFixed(2)}B`
  if (n >= 1e6)  return `$${(n / 1e6).toFixed(1)}M`
  if (n >= 1e3)  return `$${(n / 1e3).toFixed(0)}K`
  return `$${Number(n).toFixed(decimals)}`
}

export const fmtPct = (n, d = 1) => `${Number(n).toFixed(d)}%`

export const fmtNumber = (n) => Number(n).toLocaleString()

export const fmtDate = (d) =>
  format(typeof d === 'string' ? new Date(d) : d, 'MMM d, yyyy')

export const fmtTime = (d) =>
  format(typeof d === 'string' ? new Date(d) : d, 'h:mm a')

export const fmtFull = (d) =>
  format(typeof d === 'string' ? new Date(d) : d, 'MMM d, yyyy · h:mm a')

export const fmtRelative = (d) =>
  formatDistanceToNow(typeof d === 'string' ? new Date(d) : d, { addSuffix: true })

// ─── TOKEN PRICE ──────────────────────────────────────────────────────────────
export const fmtPrice = (p) => `$${p.toFixed(4)}`

// ─── GOVERNANCE ───────────────────────────────────────────────────────────────
export const getTierMeta = (tierId) =>
  GOVERNANCE_TIERS.find(t => t.id === tierId) ?? GOVERNANCE_TIERS[0]

export const calcVotingWeight = (sac1Balance, tier, lockMultiplier = 1.0) => {
  const tierMeta = getTierMeta(tier)
  return Math.round(sac1Balance * tierMeta.weightNum * lockMultiplier)
}

export const calcQuorumPct = (participated, total) =>
  total > 0 ? (participated / total) * 100 : 0

// ─── WALLET ───────────────────────────────────────────────────────────────────
export const truncateAddress = (addr, start = 6, end = 4) => {
  if (!addr) return ''
  return `${addr.slice(0, start)}…${addr.slice(-end)}`
}

export const isValidEthAddress = (addr) => /^0x[a-fA-F0-9]{40}$/.test(addr)

// ─── 2FA CODE ─────────────────────────────────────────────────────────────────
export const generateCode = () =>
  String(Math.floor(100000 + Math.random() * 900000))

// ─── TICKET ID ────────────────────────────────────────────────────────────────
let _ticketCounter = 1000
export const generateTicketId = () => `TKT-${++_ticketCounter}`

// ─── MISC ─────────────────────────────────────────────────────────────────────
export const clamp = (val, min, max) => Math.min(Math.max(val, min), max)

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

export const cn = (...classes) => classes.filter(Boolean).join(' ')

// ─── PROPOSAL STATUS ─────────────────────────────────────────────────────────
export const PROPOSAL_STATUS_META = {
  ACTIVE:  { color: '#6D28D9', label: '● ACTIVE',  bg: '#EDE9FE' },
  PASSED:  { color: '#059669', label: '✓ PASSED',  bg: '#D1FAE5' },
  FAILED:  { color: '#DC2626', label: '✗ FAILED',  bg: '#FEE2E2' },
  PENDING: { color: '#D97706', label: '○ PENDING', bg: '#FEF3C7' },
}

// ─── TICKET STATUS META ───────────────────────────────────────────────────────
export const TICKET_STATUS_META = {
  'OPEN':        { color: '#C2410C', bg: '#FFEDD5', label: 'OPEN' },
  'IN PROGRESS': { color: '#4338CA', bg: '#E0E7FF', label: 'IN PROGRESS' },
  'RESOLVED':    { color: '#059669', bg: '#D1FAE5', label: 'RESOLVED' },
  'CLOSED':      { color: '#7B88B0', bg: '#EEF0FB', label: 'CLOSED' },
}

export const TICKET_PRIORITY_META = {
  HIGH:   { color: '#DC2626', bg: '#FEE2E2' },
  MEDIUM: { color: '#D97706', bg: '#FEF3C7' },
  LOW:    { color: '#059669', bg: '#D1FAE5' },
}
