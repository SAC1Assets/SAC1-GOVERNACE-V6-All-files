/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { createContext, useContext, useState, useEffect } from 'react'
import api from '@/services/api'
import { ENDPOINTS } from '@/constants'

const PriceContext = createContext(null)

const INITIAL_SAC1 = {
  price: 0.2847,
  change: 2.34,
  history: Array.from({ length: 30 }, (_, i) => 0.26 + Math.sin(i * 0.4) * 0.02 + i * 0.0008),
}
const INITIAL_USDC = {
  price: 1.0002,
  change: 0.01,
  history: Array.from({ length: 30 }, (_, i) => 0.9998 + Math.sin(i * 0.3) * 0.0002),
}

export function PriceProvider({ children }) {
  const [sac1, setSac1] = useState(INITIAL_SAC1)
  const [usdc, setUsdc] = useState(INITIAL_USDC)
  const [connected, setConnected] = useState(false)

  // Try to fetch from backend; fall back to simulated prices
  useEffect(() => {
    let interval

    const fetchPrices = async () => {
      try {
        const { data } = await api.get(ENDPOINTS.PRICES_LIVE)
        setSac1(p => ({
          price:   data.sac1.price,
          change:  data.sac1.change24h,
          history: [...p.history.slice(1), data.sac1.price],
        }))
        setUsdc(p => ({
          price:   data.usdc.price,
          change:  data.usdc.change24h,
          history: [...p.history.slice(1), data.usdc.price],
        }))
        setConnected(true)
      } catch {
        // Backend unavailable — simulate
        setSac1(p => {
          const d  = (Math.random() - 0.48) * 0.003
          const np = Math.max(0.20, p.price + d)
          return { price: np, change: p.change + (Math.random() - 0.5) * 0.1, history: [...p.history.slice(1), np] }
        })
        setUsdc(p => {
          const d  = (Math.random() - 0.5) * 0.0003
          const np = Math.max(0.999, Math.min(1.001, p.price + d))
          return { price: np, change: p.change + (Math.random() - 0.5) * 0.005, history: [...p.history.slice(1), np] }
        })
      }
    }

    fetchPrices()
    interval = setInterval(fetchPrices, 8000)
    return () => clearInterval(interval)
  }, [])

  return (
    <PriceContext.Provider value={{ sac1, usdc, connected }}>
      {children}
    </PriceContext.Provider>
  )
}

export function usePrices() {
  const ctx = useContext(PriceContext)
  if (!ctx) throw new Error('usePrices must be inside PriceProvider')
  return ctx
}
