/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '@/services/api'
import { ENDPOINTS, ROLES } from '@/constants'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user,        setUser]        = useState(null)
  const [adminUser,   setAdminUser]   = useState(null)
  const [role,        setRole]        = useState(ROLES.GUEST)
  const [loading,     setLoading]     = useState(true)
  const [pendingEmail,setPendingEmail]= useState(null)   // for 2FA flow
  const [pendingRole, setPendingRole] = useState(null)

  // ─── Bootstrap: check stored session ────────────────────────────────────────
  useEffect(() => {
    const token = localStorage.getItem('sac1_token')
    const storedRole = localStorage.getItem('sac1_role')
    if (token) {
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`
      api.get(ENDPOINTS.USERS_ME)
        .then(({ data }) => {
          if (storedRole === ROLES.ADMIN) {
            setAdminUser(data)
            setRole(ROLES.ADMIN)
          } else {
            setUser(data)
            setRole(ROLES.HOLDER)
          }
        })
        .catch(() => {
          localStorage.removeItem('sac1_token')
          localStorage.removeItem('sac1_role')
        })
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [])

  // ─── Holder login (step 1 — returns pending 2FA) ─────────────────────────────
  const loginHolder = useCallback(async (identifier, password) => {
    const { data } = await api.post(ENDPOINTS.AUTH_LOGIN, { identifier, password })
    // Backend returns { requires2FA: true, email: '...' } or a token
    if (data.requires2FA) {
      setPendingEmail(data.email)
      setPendingRole(ROLES.HOLDER)
      return { requires2FA: true, email: data.email }
    }
    // If backend skips 2FA (e.g. dev mode)
    _persistSession(data.token, ROLES.HOLDER)
    setUser(data.user)
    setRole(ROLES.HOLDER)
    return { requires2FA: false }
  }, [])

  // ─── Admin login (step 1) ────────────────────────────────────────────────────
  const loginAdmin = useCallback(async (username, password) => {
    const { data } = await api.post(ENDPOINTS.AUTH_ADMIN_LOGIN, { username, password })
    if (data.requires2FA) {
      setPendingEmail(data.email)
      setPendingRole(ROLES.ADMIN)
      return { requires2FA: true, email: data.email }
    }
    _persistSession(data.token, ROLES.ADMIN)
    setAdminUser(data.user)
    setRole(ROLES.ADMIN)
    return { requires2FA: false }
  }, [])

  // ─── Verify 2FA (step 2) ─────────────────────────────────────────────────────
  const verify2FA = useCallback(async (code) => {
    const { data } = await api.post(ENDPOINTS.AUTH_VERIFY_2FA, {
      code,
      email: pendingEmail,
      role: pendingRole,
    })
    _persistSession(data.token, pendingRole)
    if (pendingRole === ROLES.ADMIN) {
      setAdminUser(data.user)
      setRole(ROLES.ADMIN)
    } else {
      setUser(data.user)
      setRole(ROLES.HOLDER)
    }
    setPendingEmail(null)
    setPendingRole(null)
  }, [pendingEmail, pendingRole])

  // ─── Register ────────────────────────────────────────────────────────────────
  const register = useCallback(async (formData) => {
    const { data } = await api.post(ENDPOINTS.AUTH_REGISTER, formData)
    // Registration triggers 2FA email before session is created
    setPendingEmail(formData.email)
    setPendingRole(ROLES.HOLDER)
    return data
  }, [])

  // ─── Logout ──────────────────────────────────────────────────────────────────
  const logout = useCallback(async () => {
    try { await api.post(ENDPOINTS.AUTH_LOGOUT) } catch (_) {}
    localStorage.removeItem('sac1_token')
    localStorage.removeItem('sac1_role')
    delete api.defaults.headers.common['Authorization']
    setUser(null)
    setAdminUser(null)
    setRole(ROLES.GUEST)
  }, [])

  // ─── Update current user (after profile edit) ────────────────────────────────
  const updateUser = useCallback((updates) => {
    setUser(prev => ({ ...prev, ...updates }))
  }, [])

  // ─── Internal helpers ────────────────────────────────────────────────────────
  function _persistSession(token, r) {
    localStorage.setItem('sac1_token', token)
    localStorage.setItem('sac1_role', r)
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`
  }

  const isAuthenticated = role !== ROLES.GUEST
  const isAdmin         = role === ROLES.ADMIN
  const currentUser     = isAdmin ? adminUser : user

  return (
    <AuthContext.Provider value={{
      user: currentUser,
      role,
      isAuthenticated,
      isAdmin,
      loading,
      pendingEmail,
      loginHolder,
      loginAdmin,
      verify2FA,
      register,
      logout,
      updateUser,
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be inside AuthProvider')
  return ctx
}
