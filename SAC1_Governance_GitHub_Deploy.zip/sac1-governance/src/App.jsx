/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { AuthProvider } from '@/context/AuthContext'
import { PriceProvider } from '@/context/PriceContext'

// Auth pages
import RoleGate       from '@/pages/auth/RoleGate'
import SignUpPage      from '@/pages/auth/SignUpPage'
import HolderLogin     from '@/pages/auth/HolderLogin'
import AdminLogin      from '@/pages/auth/AdminLogin'
import TwoFactorPage   from '@/pages/auth/TwoFactorPage'
import ForgotPassword  from '@/pages/auth/ForgotPassword'

// Dashboard pages
import DashboardLayout from '@/pages/dashboard/DashboardLayout'
import TreasuryTab     from '@/pages/dashboard/TreasuryTab'
import ComplianceTab   from '@/pages/dashboard/ComplianceTab'
import VotingTab       from '@/pages/dashboard/VotingTab'
import SupportTab      from '@/pages/dashboard/SupportTab'
import StakingTab      from '@/pages/dashboard/StakingTab'

// Admin pages
import AdminUsersTab   from '@/pages/admin/AdminUsersTab'
import AdminLayout     from '@/pages/admin/AdminLayout'

// Membership pages
import MembershipPage  from '@/pages/membership/MembershipPage'

function ProtectedRoute({ children, requireAdmin = false }) {
  const { user, isAdmin, isAuthenticated } = useAuth()
  if (!isAuthenticated) return <Navigate to="/" replace />
  if (requireAdmin && !isAdmin) return <Navigate to="/dashboard/treasury" replace />
  return children
}

function AppRoutes() {
  const { isAuthenticated, isAdmin } = useAuth()

  return (
    <Routes>
      {/* Public routes */}
      <Route path="/"              element={<RoleGate />} />
      <Route path="/signup"        element={<SignUpPage />} />
      <Route path="/login"         element={<HolderLogin />} />
      <Route path="/admin/login"   element={<AdminLogin />} />
      <Route path="/2fa"           element={<TwoFactorPage />} />
      <Route path="/forgot"        element={<ForgotPassword />} />
      <Route path="/membership"    element={<MembershipPage />} />

      {/* Token Holder Dashboard */}
      <Route path="/dashboard" element={
        <ProtectedRoute>
          <DashboardLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="treasury" replace />} />
        <Route path="treasury"   element={<TreasuryTab />} />
        <Route path="compliance" element={<ComplianceTab />} />
        <Route path="voting"     element={<VotingTab />} />
        <Route path="support"    element={<SupportTab />} />
        <Route path="staking"    element={<StakingTab />} />
      </Route>

      {/* Admin Dashboard */}
      <Route path="/admin" element={
        <ProtectedRoute requireAdmin>
          <AdminLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="treasury" replace />} />
        <Route path="treasury"   element={<TreasuryTab />} />
        <Route path="compliance" element={<ComplianceTab />} />
        <Route path="voting"     element={<VotingTab />} />
        <Route path="support"    element={<SupportTab />} />
        <Route path="users"      element={<AdminUsersTab />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <PriceProvider>
        <AppRoutes />
      </PriceProvider>
    </AuthProvider>
  )
}
