/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
// ─── Shared UI primitives used across the entire application ─────────────────

// SparkLine chart
export function Spark({ data = [], color, w = 90, h = 26 }) {
  const mn  = Math.min(...data)
  const mx  = Math.max(...data)
  const rng = mx - mn || 0.001
  const pts = data.map((v, i) =>
    `${(i / (data.length - 1)) * w},${h - ((v - mn) / rng) * (h - 4) - 2}`
  ).join(' ')
  return (
    <svg width={w} height={h} style={{ display: 'block' }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

// Progress bar
export function Bar({ pct = 0, color, h = 5 }) {
  return (
    <div style={{ height: h, background: 'var(--border)', borderRadius: 3, overflow: 'hidden', width: '100%' }}>
      <div style={{ height: '100%', width: `${Math.min(100, pct)}%`, background: color, borderRadius: 3, transition: 'width .7s' }} />
    </div>
  )
}

// Coloured tag badge
export function Tag({ label, color, bg }) {
  return (
    <span style={{
      fontSize: 10, padding: '3px 8px', borderRadius: 20,
      background: bg ?? `${color}18`, color,
      fontFamily: 'var(--font-mono)', fontWeight: 700,
      letterSpacing: '.08em', whiteSpace: 'nowrap',
    }}>
      {label}
    </span>
  )
}

// Pill (outlined tag)
export function Pill({ label, color }) {
  return (
    <span style={{
      fontSize: 10, padding: '2px 7px', borderRadius: 5,
      background: `${color}15`, color,
      fontFamily: 'var(--font-mono)',
      border: `1px solid ${color}30`,
    }}>
      {label}
    </span>
  )
}

// Card wrapper
export function Card({ children, style, gradient, onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: gradient ?? 'var(--panel)',
        borderRadius: 'var(--radius-lg)',
        border: '1.5px solid var(--border)',
        padding: 22,
        boxShadow: 'var(--shadow-sm)',
        cursor: onClick ? 'pointer' : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  )
}

// Section title
export function STitle({ children, color }) {
  return (
    <div style={{
      fontSize: 10, letterSpacing: '.2em',
      color: color ?? 'var(--text-muted)',
      textTransform: 'uppercase',
      fontFamily: 'var(--font-mono)', fontWeight: 700,
      marginBottom: 14,
    }}>
      {children}
    </div>
  )
}

// Loading spinner
export function Spinner({ size = 16, color = '#fff' }) {
  return (
    <span style={{
      display: 'inline-block', width: size, height: size,
      border: `2px solid ${color}30`,
      borderTop: `2px solid ${color}`,
      borderRadius: '50%',
      animation: 'spin .7s linear infinite',
    }} />
  )
}

// Bold back button
export function BackBtn({ onClick, label = 'Back', dark = false }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 7,
        padding: '10px 20px', borderRadius: 11,
        background: dark ? 'rgba(255,255,255,.14)' : `linear-gradient(135deg,var(--sac),var(--indigo))`,
        border: dark ? '2px solid rgba(255,255,255,.38)' : '2px solid var(--sac-d)',
        color: '#fff',
        fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 14,
        cursor: 'pointer',
        boxShadow: dark ? '0 4px 14px rgba(0,0,0,.3)' : 'var(--shadow-sac)',
        letterSpacing: '.02em',
      }}
    >
      ← {label}
    </button>
  )
}

// Toggle switch
export function Toggle({ on, onChange, disabled }) {
  return (
    <div
      onClick={() => !disabled && onChange?.(!on)}
      style={{
        width: 38, height: 22,
        background: on ? 'var(--green)' : 'var(--border)',
        borderRadius: 11, position: 'relative',
        cursor: disabled ? 'not-allowed' : 'pointer',
        transition: 'background .2s', flexShrink: 0,
        opacity: disabled ? 0.5 : 1,
      }}
    >
      <div style={{
        position: 'absolute', top: 3,
        left: on ? 19 : 3,
        width: 16, height: 16, borderRadius: '50%',
        background: '#fff', boxShadow: '0 1px 4px rgba(0,0,0,.18)',
        transition: 'left .2s',
      }} />
    </div>
  )
}

// Live indicator dot
export function LiveDot({ color = '#059669' }) {
  return (
    <div style={{
      width: 7, height: 7, borderRadius: '50%',
      background: color,
      animation: 'blink 1.4s infinite',
    }} />
  )
}

// Tier badge (avatar-style)
export function TierBadge({ tier }) {
  const meta = {
    community:  { color: '#0F9B8E', icon: '🌍', name: 'Community' },
    governance: { color: '#6D28D9', icon: '🗳️', name: 'Governance' },
    treasury:   { color: '#B45309', icon: '⚡', name: 'Treasury Council' },
    founding:   { color: '#1D4ED8', icon: '🏛️', name: 'Founding Partner' },
  }[tier] ?? { color: '#7B88B0', icon: '🌍', name: tier }

  return (
    <span style={{
      fontSize: 10, padding: '2px 7px', borderRadius: 10,
      background: `${meta.color}18`, color: meta.color,
      fontFamily: 'var(--font-mono)', fontWeight: 700, letterSpacing: '.08em',
    }}>
      {meta.icon} {meta.name}
    </span>
  )
}
