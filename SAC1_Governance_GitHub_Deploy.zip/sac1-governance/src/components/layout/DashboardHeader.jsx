/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { usePrices } from '@/context/PriceContext'
import { fmtPrice } from '@/utils'
import { TierBadge, LiveDot } from '@/components/ui'

export default function DashboardHeader({ onConnectWallet, wallet, onToggleLock, locked, isAdmin, onToggleChat, chatOpen }) {
  const { user, logout, isAdmin: adminMode } = useAuth()
  const { sac1 } = usePrices()
  const navigate = useNavigate()

  const handleLogout = async () => {
    await logout()
    navigate('/')
  }

  return (
    <header style={{
      background: 'var(--panel)',
      borderBottom: '1.5px solid var(--border)',
      padding: '12px 28px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      boxShadow: 'var(--shadow-sm)',
      position: 'sticky', top: 0, zIndex: 50,
    }}>
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 11, cursor: 'pointer' }} onClick={() => navigate(isAdmin ? '/admin' : '/dashboard')}>
        <div style={{ width: 36, height: 36, borderRadius: 10, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'var(--shadow-sac)' }}>
          <span style={{ fontSize: 16, fontWeight: 900, color: '#fff', fontFamily: 'var(--font-display)' }}>S</span>
        </div>
        <div>
          <div style={{ fontSize: 15, fontWeight: 800, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>SAC1 Governance</div>
          <div style={{ fontSize: 9, color: 'var(--text-muted)', letterSpacing: '.15em', textTransform: 'uppercase', fontFamily: 'var(--font-mono)' }}>SableAssent Coin Corporation</div>
        </div>
      </div>

      {/* Right controls */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
        {/* SAC1 price pill */}
        <div style={{ padding: '4px 10px', borderRadius: 8, background: 'var(--sac-l)', display: 'flex', gap: 5, alignItems: 'center' }}>
          <span style={{ fontSize: 9, fontWeight: 700, color: 'var(--sac)', fontFamily: 'var(--font-mono)' }}>SAC1</span>
          <span style={{ fontSize: 11, fontWeight: 900, color: 'var(--sac)', fontFamily: 'var(--font-mono)' }}>{fmtPrice(sac1.price)}</span>
          <span style={{ fontSize: 9, color: sac1.change >= 0 ? 'var(--green)' : 'var(--red)', fontFamily: 'var(--font-mono)' }}>
            {sac1.change >= 0 ? '▲' : '▼'}{Math.abs(sac1.change).toFixed(2)}%
          </span>
        </div>

        {/* Wallet */}
        {wallet
          ? <div style={{ padding: '4px 10px', borderRadius: 8, background: 'var(--green-l)', display: 'flex', gap: 5, alignItems: 'center', border: '1px solid rgba(5,150,105,.22)' }}>
              <LiveDot />
              <span style={{ fontSize: 9, color: 'var(--green)', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>{wallet.address}</span>
            </div>
          : <button onClick={onConnectWallet} style={{ padding: '5px 12px', borderRadius: 8, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 10, cursor: 'pointer', boxShadow: 'var(--shadow-sac)', display: 'flex', alignItems: 'center', gap: 4 }}>
              🔗 Connect Wallet
            </button>
        }

        {/* User badge */}
        <div style={{ padding: '4px 10px', borderRadius: 8, background: isAdmin ? 'var(--sac-l)' : 'var(--green-l)', border: `1px solid ${isAdmin ? 'rgba(109,40,217,.22)' : 'rgba(5,150,105,.22)'}` }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: isAdmin ? 'var(--sac)' : 'var(--green)', fontFamily: 'var(--font-mono)' }}>
            {isAdmin ? '🏛️' : '🪙'} {user?.name ?? (isAdmin ? 'Admin' : 'Token Holder')}
          </div>
          {!isAdmin && user?.tier && <div style={{ marginTop: 2 }}><TierBadge tier={user.tier} /></div>}
          {isAdmin && user?.title && <div style={{ fontSize: 7, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{user.title}</div>}
        </div>

        {/* Admin lock */}
        {isAdmin && (
          <button onClick={onToggleLock} style={{ padding: '5px 12px', borderRadius: 8, background: locked ? 'var(--red-l)' : 'var(--green-l)', border: `1.5px solid ${locked ? 'rgba(220,38,38,.35)' : 'rgba(5,150,105,.35)'}`, color: locked ? 'var(--red)' : 'var(--green)', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 10, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 3 }}>
            {locked ? '🔒 LOCKED' : '🔓 UNLOCKED'}
          </button>
        )}

        {/* Chat toggle (holder only) */}
        {!isAdmin && (
          <button onClick={onToggleChat} style={{ padding: '5px 12px', borderRadius: 8, background: chatOpen ? 'var(--sac-l)' : 'linear-gradient(135deg,var(--sac),var(--indigo))', border: chatOpen ? '1.5px solid var(--sac)' : 'none', color: chatOpen ? 'var(--sac)' : '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 10, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 3 }}>
            💬 {chatOpen ? 'Close' : 'Chat Admin'}
          </button>
        )}

        {/* Logout / Switch */}
        <button onClick={handleLogout} style={{ padding: '7px 16px', borderRadius: 10, background: isAdmin ? 'linear-gradient(135deg,var(--red),#991B1B)' : 'linear-gradient(135deg,#C2410C,var(--amber))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 12, cursor: 'pointer', boxShadow: isAdmin ? '0 3px 12px rgba(220,38,38,.4)' : '0 3px 12px rgba(194,65,12,.4)', display: 'flex', alignItems: 'center', gap: 5, letterSpacing: '.02em' }}>
          {isAdmin ? '🚪 LOGOUT' : '⇄ SWITCH'}
        </button>
      </div>
    </header>
  )
}
