/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'

const HOLDER_NAV = [
  { to: '/dashboard/treasury',   icon: '💰', label: 'Treasury'   },
  { to: '/dashboard/compliance', icon: '🛡️', label: 'Compliance' },
  { to: '/dashboard/voting',     icon: '🗳️', label: 'Voting'     },
  { to: '/dashboard/support',    icon: '🎫', label: 'Support'    },
  { to: '/dashboard/staking',    icon: '🔒', label: 'Staking'    },
]

const ADMIN_NAV = [
  { to: '/admin/treasury',   icon: '💰', label: 'Treasury'       },
  { to: '/admin/compliance', icon: '🛡️', label: 'Compliance'     },
  { to: '/admin/voting',     icon: '🗳️', label: 'Voting'         },
  { to: '/admin/support',    icon: '🎫', label: 'Support Inbox'  },
  { to: '/admin/users',      icon: '👤', label: 'Users'          },
]

const MGMT_NAV = [
  { icon: '👥', label: 'Investors' },
  { icon: '📋', label: 'Reports'   },
  { icon: '⚙️', label: 'Settings'  },
]

export default function Sidebar() {
  const { user, isAdmin } = useAuth()
  const nav = isAdmin ? ADMIN_NAV : HOLDER_NAV

  const activeStyle = {
    background: 'rgba(109,40,217,.14)',
    border: '1px solid rgba(109,40,217,.3)',
    borderRadius: 9,
  }

  return (
    <aside style={{ width: 220, background: 'var(--panel)', borderRight: '1.5px solid var(--border)', display: 'flex', flexDirection: 'column', flexShrink: 0, position: 'sticky', top: 0, height: '100vh', overflowY: 'auto' }}>
      {/* Header */}
      <div style={{ padding: '20px 18px 16px', borderBottom: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, fontWeight: 900, color: '#fff', fontFamily: 'var(--font-display)' }}>S</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 800, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>SableAssent</div>
            <div style={{ fontSize: 8, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '.14em' }}>
              {isAdmin ? 'ADMIN PORTAL' : 'GOVERNANCE HUB'}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav style={{ padding: '10px 9px', flex: 1 }}>
        <div style={{ fontSize: 8, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '.18em', padding: '6px 9px 7px', textTransform: 'uppercase' }}>Navigation</div>
        {nav.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 9,
              padding: '9px 11px', borderRadius: 9, marginBottom: 2,
              textDecoration: 'none', transition: 'all .15s',
              ...(isActive ? activeStyle : {}),
            })}
          >
            {({ isActive }) => (
              <>
                <span style={{ fontSize: 14 }}>{item.icon}</span>
                <span style={{ fontSize: 12, fontWeight: isActive ? 600 : 400, color: isActive ? 'var(--sac)' : 'var(--text-muted)', fontFamily: 'var(--font-body)' }}>
                  {item.label}
                </span>
              </>
            )}
          </NavLink>
        ))}

        <div style={{ fontSize: 8, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '.18em', padding: '14px 9px 7px', textTransform: 'uppercase' }}>Management</div>
        {MGMT_NAV.map(item => (
          <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '9px 11px', borderRadius: 9, marginBottom: 2, cursor: 'pointer', opacity: 0.5 }}>
            <span style={{ fontSize: 14 }}>{item.icon}</span>
            <span style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-body)' }}>{item.label}</span>
          </div>
        ))}
      </nav>

      {/* User badge */}
      <div style={{ padding: '12px 14px', borderTop: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'linear-gradient(135deg,var(--amber),#F59E0B)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, flexShrink: 0 }}>
            {user?.name?.[0] ?? 'U'}
          </div>
          <div>
            <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text)', fontFamily: 'var(--font-body)' }}>{user?.name ?? 'User'}</div>
            <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
              {isAdmin ? user?.title ?? 'Admin' : user?.tier ?? 'member'}
            </div>
          </div>
        </div>
      </div>
    </aside>
  )
}
