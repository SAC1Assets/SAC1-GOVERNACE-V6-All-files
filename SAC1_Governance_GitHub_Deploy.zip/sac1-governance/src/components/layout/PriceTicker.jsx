/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { usePrices } from '@/context/PriceContext'
import { Spark } from '@/components/ui'
import { fmtPrice } from '@/utils'

const EXTRA_TICKERS = [
  { sym: 'BTC/USD',    price: '$97,420', chg: '+1.12%', up: true  },
  { sym: 'ETH/USD',    price: '$3,640',  chg: '-0.42%', up: false },
  { sym: 'XAU/USD',    price: '$2,341',  chg: '+0.87%', up: true  },
]

export default function PriceTicker() {
  const { sac1, usdc } = usePrices()

  const items = [
    { sym: 'SAC1/USD', price: fmtPrice(sac1.price), chg: `${sac1.change >= 0 ? '+' : ''}${sac1.change.toFixed(2)}%`, up: sac1.change >= 0, hist: sac1.history, col: sac1.change >= 0 ? '#6EE7B7' : '#FCA5A5' },
    { sym: 'USDC',     price: fmtPrice(usdc.price), chg: `${usdc.change >= 0 ? '+' : ''}${usdc.change.toFixed(3)}%`, up: usdc.change >= 0, hist: usdc.history, col: '#93C5FD' },
    ...EXTRA_TICKERS,
  ]
  const doubled = [...items, ...items]

  return (
    <div style={{ background: 'linear-gradient(90deg,#4C1D95,#6D28D9,#2563EB)', padding: '8px 0', overflow: 'hidden', position: 'relative' }}>
      <div style={{ display: 'flex', width: 'max-content', animation: 'ticker 32s linear infinite' }}>
        {doubled.map((t, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 28px', borderRight: '1px solid rgba(255,255,255,.12)', flexShrink: 0 }}>
            <span style={{ fontSize: 10, color: 'rgba(255,255,255,.55)', fontFamily: 'var(--font-mono)', letterSpacing: '.1em' }}>{t.sym}</span>
            <span style={{ fontSize: 12, fontWeight: 700, color: '#fff', fontFamily: 'var(--font-mono)' }}>{t.price}</span>
            <span style={{ fontSize: 10, fontWeight: 700, color: t.up ? '#6EE7B7' : '#FCA5A5', fontFamily: 'var(--font-mono)' }}>{t.chg}</span>
            {t.hist && <Spark data={t.hist} color={t.col} w={60} h={20} />}
          </div>
        ))}
      </div>
    </div>
  )
}
