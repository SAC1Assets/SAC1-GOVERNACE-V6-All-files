/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
// ─── WalletModal ──────────────────────────────────────────────────────────────
export function WalletModal({ onConnect, onClose }) {
  const wallets = [
    { name: 'MetaMask',       icon: '🦊', desc: 'Browser extension' },
    { name: 'WalletConnect',  icon: '🔗', desc: 'Scan with mobile'  },
    { name: 'Coinbase Wallet',icon: '🔵', desc: 'Smart wallet'      },
    { name: 'Phantom',        icon: '👻', desc: 'Multi-chain'       },
  ]
  return (
    <Overlay onClose={onClose}>
      <ModalBox style={{ width: 370 }}>
        <ModalHeader title="Connect Wallet" sub="Choose your provider" onClose={onClose} />
        {wallets.map(w => (
          <div key={w.name} onClick={() => onConnect(w.name)}
            style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '11px 13px', borderRadius: 10, border: '1.5px solid var(--border)', marginBottom: 7, cursor: 'pointer', background: 'var(--bg)' }}>
            <div style={{ fontSize: 22, width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--panel)', borderRadius: 9, border: '1px solid var(--border)' }}>{w.icon}</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>{w.name}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-body)' }}>{w.desc}</div>
            </div>
            <div style={{ marginLeft: 'auto', color: 'var(--text-muted)', fontSize: 16 }}>›</div>
          </div>
        ))}
        <div style={{ marginTop: 11, padding: '9px 13px', borderRadius: 9, background: 'var(--sac-l)', fontSize: 9, color: 'var(--sac)', fontFamily: 'var(--font-mono)', lineHeight: 1.6 }}>🔒 Session-only. Wallet never stored on our servers.</div>
      </ModalBox>
    </Overlay>
  )
}

// ─── SendSAC1Modal ────────────────────────────────────────────────────────────
import { useState } from 'react'
export function SendSAC1Modal({ onClose, onSend, walletAddress, sac1Price, prefillWallet, prefillName }) {
  const [rec,  setRec]  = useState(prefillWallet ?? '')
  const [amt,  setAmt]  = useState('')
  const [memo, setMemo] = useState('')

  return (
    <Overlay onClose={onClose}>
      <ModalBox style={{ width: 410 }}>
        <ModalHeader title="Send SAC1 (POS)" sub="Admin governance transfer" onClose={onClose} />

        <FLabel>FROM (ADMIN TREASURY)</FLabel>
        <div style={{ padding: '9px 11px', borderRadius: 9, background: 'var(--sac-l)', fontSize: 10, fontFamily: 'var(--font-mono)', color: 'var(--sac)', marginBottom: 12 }}>{walletAddress ?? '0x1A2B…ADMIN'}</div>

        <FLabel>{`RECIPIENT WALLET${prefillName ? ` — ${prefillName}` : ''}`}</FLabel>
        {prefillName && <div style={{ padding: '6px 11px', borderRadius: 8, background: 'var(--green-l)', border: '1px solid rgba(5,150,105,.25)', marginBottom: 6, fontSize: 10, color: 'var(--green)', fontFamily: 'var(--font-mono)' }}>✓ Sending to {prefillName}</div>}
        <input value={rec} onChange={e => setRec(e.target.value)} placeholder="0x…"
          style={FInput({ shade: prefillWallet ? 'var(--sac-l)' : 'var(--bg-alt)', mono: true })} />

        <FLabel style={{ marginTop: 12 }}>AMOUNT (SAC1)</FLabel>
        <div style={{ position: 'relative' }}>
          <input value={amt} onChange={e => setAmt(e.target.value)} type="number" placeholder="0.00"
            style={{ ...FInput({ mono: true }), paddingRight: 56 }} />
          <span style={{ position: 'absolute', right: 11, top: '50%', transform: 'translateY(-50%)', fontSize: 9, color: 'var(--sac)', fontFamily: 'var(--font-mono)', fontWeight: 700 }}>SAC1</span>
        </div>
        {amt && <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginTop: 3 }}>≈ ${(parseFloat(amt || 0) * sac1Price).toFixed(4)} USD</div>}

        <FLabel style={{ marginTop: 12 }}>MEMO</FLabel>
        <input value={memo} onChange={e => setMemo(e.target.value)} placeholder="Governance grant, advisor allocation…" style={FInput({})} />

        <div style={{ display: 'flex', gap: 9, marginTop: 16 }}>
          <button onClick={onClose} style={BtnSecondary}>Cancel</button>
          <button onClick={() => { if (rec && amt) { onSend({ recipient: rec, amount: amt, memo }); onClose() } }}
            style={{ ...BtnPrimary, flex: 2 }}>Send SAC1 →</button>
        </div>
      </ModalBox>
    </Overlay>
  )
}

// ─── PaymentModal ─────────────────────────────────────────────────────────────
export function PaymentModal({ tier, onClose, onLogin }) {
  if (!tier) return null
  return (
    <Overlay onClose={onClose}>
      <ModalBox style={{ width: 440, border: `2px solid ${tier.color}30` }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }}>
          <div>
            <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: 3 }}>SECURING YOUR GOVERNANCE SEAT</div>
            <div style={{ fontSize: 19, fontWeight: 900, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>{tier.icon} {tier.name}</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: tier.color, fontFamily: 'var(--font-mono)', marginTop: 2 }}>{tier.price} · {tier.sac1Grant} grant</div>
          </div>
          <button onClick={onClose} style={CloseBtn}>✕</button>
        </div>

        <div style={{ padding: '9px 13px', borderRadius: 9, background: `${tier.color}10`, border: `1px solid ${tier.color}25`, marginBottom: 18 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: tier.color, fontFamily: 'var(--font-mono)' }}>🎁 Welcome grant: {tier.sac1Grant} · Governance weight: {tier.weight}</div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
          <button style={{ padding: '13px 14px', borderRadius: 11, background: `linear-gradient(135deg,${tier.color},${tier.color}cc)`, border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 13, cursor: 'pointer', boxShadow: `0 5px 16px ${tier.color}35` }}>💳 Pay with USD<br /><span style={{ fontSize: 9, opacity: .8 }}>Stripe Checkout</span></button>
          <button style={{ padding: '13px 14px', borderRadius: 11, background: 'none', border: `2px solid ${tier.color}50`, color: tier.color, fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 13, cursor: 'pointer' }}>🔷 Pay with USDC<br /><span style={{ fontSize: 9, opacity: .8 }}>Crypto Payment</span></button>
        </div>

        <div style={{ height: 1, background: 'var(--border)', margin: '14px 0' }} />
        <div style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-body)', marginBottom: 9 }}>Already have a SAC1 account? Log in to link your seat.</div>
        <button onClick={() => { onClose(); onLogin?.() }}
          style={{ width: '100%', padding: '12px', borderRadius: 11, background: 'linear-gradient(135deg,var(--green),var(--teal))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 14, cursor: 'pointer', boxShadow: '0 5px 16px rgba(5,150,105,.35)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7 }}>
          🔑 Log In to Your Account
        </button>
        <div style={{ marginTop: 12, padding: '8px 12px', borderRadius: 8, background: 'var(--bg-alt)', border: '1px solid var(--border)', fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', lineHeight: 1.8 }}>⚖️ SAC1 grants governance rights — not investment returns.</div>
      </ModalBox>
    </Overlay>
  )
}

// ─── ChatPanel ────────────────────────────────────────────────────────────────
export function ChatPanel({ onClose }) {
  const [msgs, setMsgs] = useState([{ id: 1, from: 'admin', text: 'Welcome to SAC1 Governance Support. How can we help?', time: new Date() }])
  const [input, setInput] = useState('')
  const bottomRef = { current: null }

  const REPLIES = [
    "Thank you for reaching out. We'll look into this shortly.",
    "Your request has been received and is being reviewed.",
    "Our compliance team will respond within 24 hours.",
    "This has been escalated to the appropriate department.",
  ]

  const send = () => {
    if (!input.trim()) return
    const m = { id: Date.now(), from: 'user', text: input.trim(), time: new Date() }
    setMsgs(p => [...p, m])
    setInput('')
    setTimeout(() => {
      const r = REPLIES[Math.floor(Math.random() * REPLIES.length)]
      setMsgs(p => [...p, { id: Date.now() + 1, from: 'admin', text: r, time: new Date() }])
    }, 1200 + Math.random() * 800)
  }

  const fmt = d => d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })

  return (
    <div style={{ position: 'fixed', bottom: 88, right: 22, width: 330, height: 440, background: 'var(--panel)', borderRadius: 19, boxShadow: '0 14px 56px rgba(61,74,107,.18)', border: '1.5px solid var(--border)', display: 'flex', flexDirection: 'column', zIndex: 800, animation: 'slideIn .25s ease' }}>
      <div style={{ padding: '13px 14px', display: 'flex', alignItems: 'center', gap: 9, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', borderRadius: '17px 17px 0 0' }}>
        <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(255,255,255,.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15 }}>🏛️</div>
        <div style={{ flex: 1 }}><div style={{ fontSize: 12, fontWeight: 700, color: '#fff', fontFamily: 'var(--font-display)' }}>SAC1 Admin Support</div><div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 1 }}><div style={{ width: 5, height: 5, borderRadius: '50%', background: '#6EE7B7', animation: 'blink 1.5s infinite' }} /><span style={{ fontSize: 9, color: 'rgba(255,255,255,.7)', fontFamily: 'var(--font-mono)' }}>Online</span></div></div>
        <button onClick={onClose} style={{ width: 24, height: 24, borderRadius: '50%', background: 'rgba(255,255,255,.15)', border: 'none', cursor: 'pointer', fontSize: 12, color: '#fff' }}>✕</button>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '11px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {msgs.map(m => (
          <div key={m.id} style={{ display: 'flex', flexDirection: 'column', alignItems: m.from === 'user' ? 'flex-end' : 'flex-start', gap: 2 }}>
            {m.from === 'admin' && <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginLeft: 3 }}>Admin · {fmt(m.time)}</div>}
            <div style={{ maxWidth: '76%', padding: '8px 12px', borderRadius: m.from === 'user' ? '13px 13px 3px 13px' : '13px 13px 13px 3px', background: m.from === 'user' ? 'linear-gradient(135deg,var(--sac),var(--indigo))' : 'var(--bg)', color: m.from === 'user' ? '#fff' : 'var(--text)', fontSize: 11, fontFamily: 'var(--font-body)', lineHeight: 1.55, border: m.from === 'admin' ? '1px solid var(--border)' : 'none' }}>{m.text}</div>
            {m.from === 'user' && <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginRight: 3 }}>{fmt(m.time)}</div>}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <div style={{ padding: '9px 11px', borderTop: '1px solid var(--border)', display: 'flex', gap: 6, background: 'var(--bg)', borderRadius: '0 0 17px 17px' }}>
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Type a message…" style={{ flex: 1, padding: '8px 11px', borderRadius: 10, background: 'var(--panel)', border: '1.5px solid var(--border)', fontSize: 11, color: 'var(--text)' }} />
        <button onClick={send} style={{ width: 34, height: 34, borderRadius: 10, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', cursor: 'pointer', fontSize: 15, color: '#fff', boxShadow: 'var(--shadow-sac)', flexShrink: 0 }}>↑</button>
      </div>
    </div>
  )
}

// ─── Shared modal primitives ──────────────────────────────────────────────────
function Overlay({ children, onClose }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(18,24,48,.55)', backdropFilter: 'blur(5px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      onClick={e => { if (e.target === e.currentTarget) onClose?.() }}>
      {children}
    </div>
  )
}
function ModalBox({ children, style }) {
  return (
    <div style={{ background: 'var(--panel)', borderRadius: 20, border: '1.5px solid var(--border)', padding: 30, boxShadow: '0 24px 64px rgba(18,24,48,.25)', animation: 'slideIn .2s ease', maxHeight: '90vh', overflowY: 'auto', ...style }}>
      {children}
    </div>
  )
}
function ModalHeader({ title, sub, onClose }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
      <div>
        <div style={{ fontSize: 19, fontWeight: 800, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>{title}</div>
        {sub && <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2, fontFamily: 'var(--font-body)' }}>{sub}</div>}
      </div>
      <button onClick={onClose} style={CloseBtn}>✕</button>
    </div>
  )
}
function FLabel({ children, style }) {
  return <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '.14em', marginBottom: 5, textTransform: 'uppercase', ...style }}>{children}</div>
}
const FInput = ({ shade, mono }) => ({
  width: '100%', padding: '10px 11px', borderRadius: 9,
  background: shade ?? 'var(--bg-alt)',
  border: '1.5px solid var(--border)',
  fontSize: mono ? 12 : 13, fontFamily: mono ? 'var(--font-mono)' : 'var(--font-body)',
  color: 'var(--text)', boxSizing: 'border-box', marginBottom: 4,
})
const BtnPrimary = { flex: 2, padding: 11, borderRadius: 10, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 13, cursor: 'pointer', boxShadow: 'var(--shadow-sac)' }
const BtnSecondary = { flex: 1, padding: 11, borderRadius: 10, background: 'var(--bg-alt)', border: 'none', color: 'var(--text-muted)', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, cursor: 'pointer' }
const CloseBtn = { width: 30, height: 30, borderRadius: '50%', background: 'var(--bg-alt)', border: 'none', cursor: 'pointer', fontSize: 15, color: 'var(--text-muted)' }
