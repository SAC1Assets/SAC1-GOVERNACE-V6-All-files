/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useState, useRef, useEffect } from 'react'
import { Spinner } from '@/components/ui'
import { BackBtn } from '@/components/ui'

export default function TwoFactorModal({ email, onSuccess, onBack, dark = false }) {
  const [digits,  setDigits]  = useState(['','','','','',''])
  const [error,   setError]   = useState('')
  const [loading, setLoading] = useState(false)
  const [sent,    setSent]    = useState(false)

  // Individual refs (no hook in loop)
  const r0=useRef(); const r1=useRef(); const r2=useRef()
  const r3=useRef(); const r4=useRef(); const r5=useRef()
  const refs = [r0,r1,r2,r3,r4,r5]

  useEffect(() => {
    setTimeout(() => setSent(true), 700)
    refs[0].current?.focus()
  }, [])

  const setDigit = (i, val) => {
    if (!/^\d*$/.test(val)) return
    const next = [...digits]; next[i] = val.slice(-1); setDigits(next); setError('')
    if (val && i < 5) refs[i + 1].current?.focus()
  }

  const onKey = (i, e) => {
    if (e.key === 'Backspace' && !digits[i] && i > 0) refs[i - 1].current?.focus()
  }

  const onPaste = (e) => {
    const ds = e.clipboardData.getData('text').replace(/\D/g,'').slice(0,6)
    if (ds.length === 6) { setDigits(ds.split('')); refs[5].current?.focus() }
  }

  const verify = async () => {
    const code = digits.join('')
    if (code.length < 6) { setError('Enter all 6 digits.'); return }
    setLoading(true)
    try {
      await onSuccess(code)
    } catch (err) {
      setError(err.displayMessage || 'Incorrect code. Try again.')
      setDigits(['','','','','',''])
    } finally {
      setLoading(false)
    }
  }

  const tc = dark ? '#fff' : 'var(--text)'
  const mc = dark ? 'rgba(255,255,255,.45)' : 'var(--text-muted)'
  const bg = dark ? 'linear-gradient(150deg,#0A0C1E,#1A0F3C,#0C1A2E)' : 'var(--bg)'

  const inputStyle = (filled) => ({
    width: 46, height: 54, textAlign: 'center',
    fontSize: 22, fontWeight: 900, fontFamily: 'var(--font-mono)',
    borderRadius: 11,
    border: `2px solid ${filled ? (dark ? 'rgba(255,255,255,.5)' : 'var(--sac)') : (dark ? 'rgba(255,255,255,.18)' : 'var(--border)')}`,
    background: dark ? 'rgba(255,255,255,.07)' : 'var(--panel)',
    color: tc, outline: 'none', transition: 'border-color .2s',
  })

  return (
    <div style={{ minHeight: '100vh', background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' }}>
      {dark && (
        <>
          <div style={{ position: 'absolute', width: 360, height: 360, borderRadius: '50%', background: 'rgba(109,40,217,.22)', top: '-10%', left: '-6%', filter: 'blur(60px)', pointerEvents: 'none' }} />
          <div style={{ position: 'absolute', width: 260, height: 260, borderRadius: '50%', background: 'rgba(67,56,202,.18)', top: '55%', right: '-4%', filter: 'blur(60px)', pointerEvents: 'none' }} />
        </>
      )}

      <div style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: 440, padding: '0 24px' }}>
        <div style={{ marginBottom: 26 }}><BackBtn onClick={onBack} label="Back to Login" dark={dark} /></div>

        <div style={{ background: dark ? 'rgba(255,255,255,.05)' : 'var(--panel)', backdropFilter: dark ? 'blur(22px)' : 'none', borderRadius: 22, border: dark ? '1px solid rgba(255,255,255,.11)' : '1.5px solid var(--border)', padding: '38px 34px', boxShadow: dark ? '0 30px 80px rgba(0,0,0,.5)' : '0 8px 40px rgba(109,40,217,.1)', animation: 'slideIn .3s ease' }}>

          <div style={{ textAlign: 'center', marginBottom: 28 }}>
            <div style={{ width: 68, height: 68, borderRadius: '50%', background: 'linear-gradient(135deg,var(--sac),var(--indigo))', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', fontSize: 28, boxShadow: '0 6px 24px rgba(109,40,217,.4)', animation: 'pulse2fa 2s infinite' }}>🔐</div>
            <div style={{ fontSize: 22, fontWeight: 900, color: tc, fontFamily: 'var(--font-display)', marginBottom: 5 }}>Two-Factor Authentication</div>
            <div style={{ fontSize: 12, color: mc, fontFamily: 'var(--font-body)', lineHeight: 1.7 }}>A 6-digit code was sent to</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: dark ? '#A78BFA' : 'var(--sac)', fontFamily: 'var(--font-mono)', marginTop: 3 }}>{email}</div>
            {sent && <div style={{ marginTop: 10, padding: '5px 14px', borderRadius: 8, background: 'rgba(5,150,105,.15)', border: '1px solid rgba(5,150,105,.3)', display: 'inline-block' }}><span style={{ fontSize: 11, color: 'var(--green)', fontFamily: 'var(--font-mono)' }}>✓ Code sent successfully</span></div>}
          </div>

          {error && <div style={{ padding: '9px 13px', borderRadius: 9, background: 'var(--red-l)', border: '1px solid rgba(220,38,38,.3)', marginBottom: 16, textAlign: 'center' }}><span style={{ fontSize: 11, color: 'var(--red)', fontFamily: 'var(--font-mono)' }}>{error}</span></div>}

          <div style={{ marginBottom: 8, textAlign: 'center', fontSize: 10, color: mc, fontFamily: 'var(--font-mono)', letterSpacing: '.16em' }}>ENTER 6-DIGIT CODE</div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginBottom: 22 }} onPaste={onPaste}>
            {digits.map((d, i) => (
              <input key={i} ref={refs[i]} value={d} maxLength={1}
                onChange={e => setDigit(i, e.target.value)}
                onKeyDown={e => onKey(i, e)}
                style={inputStyle(!!d)}
              />
            ))}
          </div>

          <button onClick={verify} disabled={loading} style={{ width: '100%', padding: '13px', borderRadius: 12, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 14, cursor: 'pointer', boxShadow: 'var(--shadow-sac)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 14 }}>
            {loading ? <><Spinner />Verifying…</> : 'Verify & Continue →'}
          </button>

          <div style={{ textAlign: 'center', fontSize: 12, color: mc, fontFamily: 'var(--font-body)' }}>
            Didn't get it? <span style={{ color: dark ? '#A78BFA' : 'var(--sac)', fontWeight: 700, cursor: 'pointer' }} onClick={() => { setSent(false); setTimeout(() => setSent(true), 600) }}>Resend code</span>
          </div>
        </div>
      </div>
    </div>
  )
}
