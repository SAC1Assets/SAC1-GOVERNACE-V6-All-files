/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import api from './api'
import { ENDPOINTS } from '@/constants'

export const authService = {
  login:          (data) => api.post(ENDPOINTS.AUTH_LOGIN, data),
  adminLogin:     (data) => api.post(ENDPOINTS.AUTH_ADMIN_LOGIN, data),
  register:       (data) => api.post(ENDPOINTS.AUTH_REGISTER, data),
  logout:         ()     => api.post(ENDPOINTS.AUTH_LOGOUT),
  verify2FA:      (data) => api.post(ENDPOINTS.AUTH_VERIFY_2FA, data),
  send2FA:        (data) => api.post(ENDPOINTS.AUTH_SEND_2FA, data),
  forgotPassword: (data) => api.post(ENDPOINTS.AUTH_FORGOT_PASSWORD, data),
  resetPassword:  (data) => api.post(ENDPOINTS.AUTH_RESET_PASSWORD, data),
  me:             ()     => api.get(ENDPOINTS.USERS_ME),
}
