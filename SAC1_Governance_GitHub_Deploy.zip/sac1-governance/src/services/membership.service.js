/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import api from './api'
import { ENDPOINTS } from '@/constants'

export const membershipService = {
  getTiers:   ()     => api.get(ENDPOINTS.MEMBERSHIP_TIERS),
  purchase:   (data) => api.post(ENDPOINTS.MEMBERSHIP_PURCHASE, data),
  upgrade:    (data) => api.post(ENDPOINTS.MEMBERSHIP_UPGRADE, data),
  getStatus:  ()     => api.get(ENDPOINTS.MEMBERSHIP_STATUS),
}
