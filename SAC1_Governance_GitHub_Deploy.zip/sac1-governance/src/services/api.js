/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import axios from 'axios'
import { API_BASE } from '@/constants'

const api = axios.create({
  baseURL: API_BASE,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
})

// ─── Request interceptor ─────────────────────────────────────────────────────
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('sac1_token')
    if (token) config.headers.Authorization = `Bearer ${token}`
    return config
  },
  (error) => Promise.reject(error),
)

// ─── Response interceptor ────────────────────────────────────────────────────
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config

    // Auto-refresh on 401
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true
      try {
        const { data } = await axios.post(`${API_BASE}/auth/refresh`, {}, {
          withCredentials: true,
        })
        localStorage.setItem('sac1_token', data.token)
        api.defaults.headers.common['Authorization'] = `Bearer ${data.token}`
        original.headers['Authorization'] = `Bearer ${data.token}`
        return api(original)
      } catch {
        localStorage.removeItem('sac1_token')
        localStorage.removeItem('sac1_role')
        window.location.href = '/'
      }
    }

    // Normalise error message
    const message =
      error.response?.data?.message ||
      error.response?.data?.detail ||
      error.message ||
      'An unexpected error occurred'
    error.displayMessage = message

    return Promise.reject(error)
  },
)

export default api
