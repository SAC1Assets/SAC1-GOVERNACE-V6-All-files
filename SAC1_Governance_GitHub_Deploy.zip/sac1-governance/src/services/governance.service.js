/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import api from './api'
import { ENDPOINTS } from '@/constants'

export const governanceService = {
  getProposals:  ()          => api.get(ENDPOINTS.PROPOSALS_LIST),
  getProposal:   (id)        => api.get(ENDPOINTS.PROPOSALS_BY_ID(id)),
  createProposal:(data)      => api.post(ENDPOINTS.PROPOSALS_CREATE, data),
  castVote:      (id, choice)=> api.post(ENDPOINTS.PROPOSALS_VOTE(id), { choice }),
}
