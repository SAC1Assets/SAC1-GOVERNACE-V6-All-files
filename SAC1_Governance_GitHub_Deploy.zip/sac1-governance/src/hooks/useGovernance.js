/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { governanceService } from '@/services/governance.service'
import toast from 'react-hot-toast'

export function useProposals() {
  return useQuery(
    ['proposals'],
    () => governanceService.getProposals().then(r => r.data),
    { staleTime: 60_000 },
  )
}

export function useVote() {
  const qc = useQueryClient()
  return useMutation(
    ({ proposalId, choice }) => governanceService.castVote(proposalId, choice),
    {
      onSuccess: (_, { proposalId, choice }) => {
        toast.success(`Vote recorded: ${choice.toUpperCase()}`)
        qc.invalidateQueries(['proposals'])
        qc.invalidateQueries(['proposals', proposalId])
      },
      onError: (err) => toast.error(err.displayMessage || 'Vote failed'),
    },
  )
}

export function useCreateProposal() {
  const qc = useQueryClient()
  return useMutation(
    (data) => governanceService.createProposal(data),
    {
      onSuccess: () => {
        toast.success('Proposal submitted successfully')
        qc.invalidateQueries(['proposals'])
      },
      onError: (err) => toast.error(err.displayMessage || 'Proposal failed'),
    },
  )
}
