/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useQuery, useMutation, useQueryClient } from 'react-query'
import api from '@/services/api'
import { ENDPOINTS } from '@/constants'
import toast from 'react-hot-toast'

export function useUsers(params = {}) {
  return useQuery(
    ['users', params],
    () => api.get(ENDPOINTS.USERS_LIST, { params }).then(r => r.data),
    { staleTime: 30_000 },
  )
}

export function useUser(id) {
  return useQuery(
    ['users', id],
    () => api.get(ENDPOINTS.USERS_BY_ID(id)).then(r => r.data),
    { enabled: !!id },
  )
}

export function useSendSAC1() {
  const qc = useQueryClient()
  return useMutation(
    (data) => api.post(ENDPOINTS.ADMIN_SEND_SAC1, data),
    {
      onSuccess: (_, vars) => {
        toast.success(`Sent ${vars.amount} SAC1 → ${vars.recipient.slice(0, 10)}…`)
        qc.invalidateQueries(['users'])
        qc.invalidateQueries(['treasury'])
      },
      onError: (err) => toast.error(err.displayMessage || 'Transfer failed'),
    },
  )
}
