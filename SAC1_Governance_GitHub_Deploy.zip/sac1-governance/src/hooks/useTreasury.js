/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useQuery } from 'react-query'
import api from '@/services/api'
import { ENDPOINTS } from '@/constants'

export function useTreasury() {
  return useQuery(
    ['treasury'],
    () => api.get(ENDPOINTS.TREASURY_OVERVIEW).then(r => r.data),
    { staleTime: 60_000 },
  )
}

export function useDisbursements() {
  return useQuery(
    ['disbursements'],
    () => api.get(ENDPOINTS.TREASURY_DISBURSEMENTS).then(r => r.data),
    { staleTime: 30_000 },
  )
}
