/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useQuery, useMutation, useQueryClient } from 'react-query'
import api from '@/services/api'
import { ENDPOINTS } from '@/constants'
import toast from 'react-hot-toast'

export function useTickets() {
  return useQuery(
    ['tickets'],
    () => api.get(ENDPOINTS.TICKETS_LIST).then(r => r.data),
    { staleTime: 30_000 },
  )
}

export function useCreateTicket() {
  const qc = useQueryClient()
  return useMutation(
    (data) => api.post(ENDPOINTS.TICKETS_CREATE, data),
    {
      onSuccess: () => {
        toast.success('Support ticket created')
        qc.invalidateQueries(['tickets'])
      },
      onError: (err) => toast.error(err.displayMessage || 'Failed to create ticket'),
    },
  )
}

export function useReplyTicket() {
  const qc = useQueryClient()
  return useMutation(
    ({ id, message }) => api.post(ENDPOINTS.TICKETS_REPLY(id), { message }),
    {
      onSuccess: (_, { id }) => {
        qc.invalidateQueries(['tickets'])
        qc.invalidateQueries(['tickets', id])
      },
      onError: (err) => toast.error(err.displayMessage || 'Reply failed'),
    },
  )
}

export function useUpdateTicketStatus() {
  const qc = useQueryClient()
  return useMutation(
    ({ id, status }) => api.patch(ENDPOINTS.TICKETS_UPDATE(id), { status }),
    {
      onSuccess: () => {
        toast.success('Ticket status updated')
        qc.invalidateQueries(['tickets'])
      },
    },
  )
}
