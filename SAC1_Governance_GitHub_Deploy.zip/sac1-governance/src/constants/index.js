/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
// ─── GOVERNANCE TIERS ─────────────────────────────────────────────────────────
export const GOVERNANCE_TIERS = [
  {
    id: 'community',
    name: 'Community Member',
    icon: '🌍',
    price: '$100',
    priceNum: 100,
    annual: '$90/yr',
    sac1Grant: '1,000–2,500 SAC1',
    sac1GrantMin: 1000,
    sac1GrantMax: 2500,
    weight: '1x',
    weightNum: 1.0,
    color: '#0F9B8E',
    light: '#CCFBF1',
    seatsTotal: 500,
    badge: null,
    features: [
      'Full Governance Dashboard',
      '1x voting weight',
      'Treasury allocation view',
      'Support tickets + admin chat',
      'Live SAC1 & USDC prices',
      'Remittance corridor access',
      'Community governance badge',
    ],
  },
  {
    id: 'governance',
    name: 'Governance Member',
    icon: '🗳️',
    price: '$500',
    priceNum: 500,
    annual: '$490/yr',
    sac1Grant: '5,000–25,000 SAC1',
    sac1GrantMin: 5000,
    sac1GrantMax: 25000,
    weight: '1.5x',
    weightNum: 1.5,
    color: '#6D28D9',
    light: '#EDE9FE',
    seatsTotal: 200,
    badge: 'MOST POPULAR',
    features: [
      'All Community features',
      'Enhanced 1.5x voting weight',
      'Proposal submission rights',
      'Treasury governance forum',
      'Priority 4-hr support SLA',
      'Governance analytics',
      'Monthly briefing',
      'Governance Member NFT badge',
    ],
  },
  {
    id: 'treasury',
    name: 'Treasury Council',
    icon: '⚡',
    price: '$5,000',
    priceNum: 5000,
    annual: '$4,800/yr',
    sac1Grant: '50,000–250,000 SAC1',
    sac1GrantMin: 50000,
    sac1GrantMax: 250000,
    weight: '2x',
    weightNum: 2.0,
    color: '#B45309',
    light: '#FEF3C7',
    seatsTotal: 50,
    badge: null,
    features: [
      'All Governance features',
      'Advanced 2x voting weight',
      'Treasury advisory access',
      'Accept delegations',
      'SPV asset deal flow',
      'Direct admin channel',
      'Quarterly strategy call',
      'Validator node priority',
      'Treasury Council NFT',
    ],
  },
  {
    id: 'founding',
    name: 'Founding Gov. Partner',
    icon: '🏛️',
    price: '$50,000',
    priceNum: 50000,
    annual: 'Annual',
    sac1Grant: '500,000+ SAC1',
    sac1GrantMin: 500000,
    sac1GrantMax: null,
    weight: '3x',
    weightNum: 3.0,
    color: '#1D4ED8',
    light: '#DBEAFE',
    seatsTotal: 100,
    badge: null,
    features: [
      'All Treasury features',
      'Institutional 3x voting weight',
      'Governance board seat',
      'Ecosystem partnership rights',
      'Strategic initiative rights',
      'Validator licensing priority',
      'Lifetime Founding credential',
      'Named treasury seat',
    ],
  },
]

// ─── LOCK PERIODS ─────────────────────────────────────────────────────────────
export const LOCK_PERIODS = [
  { label: 'No Lock',   months: 0,  multiplier: 1.0,  display: '1.0x', color: '#7B88B0' },
  { label: '3 Months',  months: 3,  multiplier: 1.25, display: '1.25x', color: '#0F9B8E' },
  { label: '6 Months',  months: 6,  multiplier: 1.5,  display: '1.5x',  color: '#6D28D9' },
  { label: '12 Months', months: 12, multiplier: 2.0,  display: '2.0x',  color: '#B45309' },
  { label: '24 Months', months: 24, multiplier: 3.0,  display: '3.0x',  color: '#1D4ED8' },
]

// ─── GOVERNANCE RULES ─────────────────────────────────────────────────────────
export const GOVERNANCE_RULES = {
  quorumPct: 66,
  simpleMajority: 50,
  supermajority: 75,
  noticeDays: 7,
  emergencyHours: 48,
}

// ─── USER ROLES ───────────────────────────────────────────────────────────────
export const ROLES = {
  ADMIN: 'admin',
  HOLDER: 'holder',
  GUEST: 'guest',
}

// ─── KYC TIERS ────────────────────────────────────────────────────────────────
export const KYC_TIERS = {
  PENDING: 'PENDING',
  TIER_1: 'TIER 1',
  TIER_2: 'TIER 2',
}

// ─── TICKET CATEGORIES ────────────────────────────────────────────────────────
export const TICKET_CATEGORIES = [
  'Token Transfer',
  'Governance Question',
  'Compliance Issue',
  'Wallet Problem',
  'SAC1 Balance',
  'Voting Rights',
  'Staking Issue',
  'Other',
]

// ─── COMPLIANCE FRAMEWORKS ────────────────────────────────────────────────────
export const COMPLIANCE_ITEMS = [
  {
    id: 'kyc-kyb',
    title: 'KYC/KYB Onboarding',
    desc: 'Tier 2 KYC for all counterparties. Enhanced due diligence above $10K.',
    risk: 'HIGH',
    enabled: true,
    jurisdiction: 'Global',
  },
  {
    id: 'fatf-travel',
    title: 'FATF Travel Rule',
    desc: 'Originator/beneficiary data transmitted for transfers ≥$1,000 USD.',
    risk: 'HIGH',
    enabled: true,
    jurisdiction: 'Global',
  },
  {
    id: 'fincen-msb',
    title: 'FinCEN MSB Registration',
    desc: 'Active FinCEN registration mandatory for US corridors. Annual renewal.',
    risk: 'HIGH',
    enabled: true,
    jurisdiction: 'USA',
  },
  {
    id: 'mica',
    title: 'MiCA Token Classification',
    desc: 'SAC1 docs maintained under MiCA Article 3 for EU market access.',
    risk: 'MEDIUM',
    enabled: true,
    jurisdiction: 'EU',
  },
  {
    id: 'african-licensing',
    title: 'African Market Licensing',
    desc: 'Corridor licensing: Ghana (BoG), Nigeria (CBN), Liberia (CBL).',
    risk: 'MEDIUM',
    enabled: false,
    jurisdiction: 'Africa',
  },
  {
    id: 'ofac',
    title: 'OFAC/UN Sanctions Screening',
    desc: 'Real-time screening vs OFAC SDN & UN Consolidated Sanctions every tx.',
    risk: 'HIGH',
    enabled: true,
    jurisdiction: 'Global',
  },
]

// ─── TREASURY ALLOCATIONS ─────────────────────────────────────────────────────
export const TREASURY_ALLOCATIONS = [
  { label: 'Technology',        pct: 28, color: '#4338CA' },
  { label: 'Compliance & Legal',pct: 22, color: '#6D28D9' },
  { label: 'Remittance Corridors', pct: 18, color: '#059669' },
  { label: 'Sales & BD',        pct: 12, color: '#BE185D' },
  { label: 'Marketing',         pct: 10, color: '#D97706' },
  { label: 'Operations',        pct: 10, color: '#0F766E' },
]

// ─── API ENDPOINTS ────────────────────────────────────────────────────────────
export const API_BASE = import.meta.env.VITE_API_URL || '/api/v1'

export const ENDPOINTS = {
  // Auth
  AUTH_LOGIN:          '/auth/login',
  AUTH_REGISTER:       '/auth/register',
  AUTH_LOGOUT:         '/auth/logout',
  AUTH_REFRESH:        '/auth/refresh',
  AUTH_VERIFY_2FA:     '/auth/verify-2fa',
  AUTH_SEND_2FA:       '/auth/send-2fa',
  AUTH_FORGOT_PASSWORD:'/auth/forgot-password',
  AUTH_RESET_PASSWORD: '/auth/reset-password',
  AUTH_ADMIN_LOGIN:    '/auth/admin/login',

  // Users
  USERS_ME:            '/users/me',
  USERS_UPDATE:        '/users/me',
  USERS_LIST:          '/users',           // admin only
  USERS_BY_ID:         (id) => `/users/${id}`,

  // Membership
  MEMBERSHIP_TIERS:    '/membership/tiers',
  MEMBERSHIP_PURCHASE: '/membership/purchase',
  MEMBERSHIP_UPGRADE:  '/membership/upgrade',
  MEMBERSHIP_STATUS:   '/membership/status',

  // Governance / Voting
  PROPOSALS_LIST:      '/governance/proposals',
  PROPOSALS_CREATE:    '/governance/proposals',
  PROPOSALS_BY_ID:     (id) => `/governance/proposals/${id}`,
  PROPOSALS_VOTE:      (id) => `/governance/proposals/${id}/vote`,

  // Treasury
  TREASURY_OVERVIEW:   '/treasury/overview',
  TREASURY_DISBURSEMENTS: '/treasury/disbursements',
  TREASURY_SEND_SAC1:  '/treasury/send',

  // Staking
  STAKING_POSITIONS:   '/staking/positions',
  STAKING_STAKE:       '/staking/stake',
  STAKING_UNSTAKE:     '/staking/unstake',

  // Prices
  PRICES_LIVE:         '/prices/live',

  // Support
  TICKETS_LIST:        '/support/tickets',
  TICKETS_CREATE:      '/support/tickets',
  TICKETS_BY_ID:       (id) => `/support/tickets/${id}`,
  TICKETS_REPLY:       (id) => `/support/tickets/${id}/reply`,
  TICKETS_UPDATE:      (id) => `/support/tickets/${id}/status`,

  // Compliance
  COMPLIANCE_LIST:     '/compliance/rules',
  COMPLIANCE_TOGGLE:   (id) => `/compliance/rules/${id}/toggle`,

  // Wallet
  WALLET_CONNECT:      '/wallet/connect',
  WALLET_DISCONNECT:   '/wallet/disconnect',

  // Remittance
  REMITTANCE_CORRIDORS:'/remittance/corridors',
  REMITTANCE_SEND:     '/remittance/send',
  REMITTANCE_HISTORY:  '/remittance/history',

  // Admin
  ADMIN_SEND_SAC1:     '/admin/send-sac1',
  ADMIN_LOCK_DASHBOARD:'/admin/dashboard/lock',
  ADMIN_STATS:         '/admin/stats',
}
