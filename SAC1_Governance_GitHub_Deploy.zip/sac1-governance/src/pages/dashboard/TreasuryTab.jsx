/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
/**
 * pages/dashboard/TreasuryTab.jsx
 * Displays treasury overview: balance, burn, runway, allocations, treasury rules.
 * Admin: also shows disbursements and Send SAC1 button.
 */
import { useOutletContext } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { useTreasury, useDisbursements } from '@/hooks/useTreasury'
import { Bar, Card, STitle, Tag, Pill } from '@/components/ui'
import { fmtCurrency, fmtPct } from '@/utils'
import { TREASURY_ALLOCATIONS } from '@/constants'

// Static fallback data while backend is being built
const FALLBACK = {
  balance: 2840000, burn: 184000, runway: 15.4,
  balancePct: 71, burnPct: 58, runwayPct: 77,
}
const RULES = [
  { title: 'Multi-Sig Authorization', desc: 'Disbursements >$25K require 3-of-5 multi-sig.', status: 'ENFORCED', color: '#059669' },
  { title: 'Quarterly Spend Cap',     desc: 'No dept may exceed 130% of quarterly allocation.', status: 'ENFORCED', color: '#059669' },
  { title: '90-Day Reserve Floor',    desc: 'Minimum 90-day operational runway at all times.', status: 'ENFORCED', color: '#059669' },
  { title: 'SAC1 Liquidity Lock',     desc: '12-month lock, 6-month cliff, then monthly vesting.', status: 'ACTIVE', color: '#6D28D9' },
  { title: 'Reallocation Threshold',  desc: 'Budget shifts >5% require Governance Vote.', status: 'PENDING VOTE', color: '#D97706' },
]
const DISB = [
  { id: 'DISB-041', desc: 'AWS Infrastructure — Q3 Commitment',       amount: '$38,400', req: 'CTO',   sigs: 2, need: 3 },
  { id: 'DISB-042', desc: 'Legal retainer renewal — Compliance Counsel', amount: '$15,000', req: 'Legal', sigs: 3, need: 3 },
  { id: 'DISB-043', desc: 'Remittance corridor setup fee — Ghana pilot', amount: '$27,500', req: 'BD',    sigs: 1, need: 3 },
]

export default function TreasuryTab() {
  const { isAdmin } = useAuth()
  // const { data: treasury } = useTreasury()  // ← uncomment when backend ready
  const d = FALLBACK

  return (
    <div>
      {/* KPI Row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 13, marginBottom: 16 }}>
        {[
          { label: 'Treasury Balance', val: fmtCurrency(d.balance), sub: `${d.balancePct}% of target reserve`, pct: d.balancePct, color: '#059669', grad: 'linear-gradient(135deg,#D1FAE5,#CCFBF1)' },
          { label: 'Monthly Burn',     val: fmtCurrency(d.burn),    sub: `${d.burnPct}% of quarterly budget`, pct: d.burnPct,    color: '#6D28D9', grad: 'linear-gradient(135deg,#EDE9FE,#E0E7FF)' },
          { label: 'Runway',           val: `${d.runway} mo`,       sub: '✓ Above 90-day floor',              pct: d.runwayPct,  color: '#4338CA', grad: 'linear-gradient(135deg,#E0E7FF,#DBEAFE)' },
        ].map(s => (
          <Card key={s.label} gradient={s.grad}>
            <STitle color={s.color}>{s.label}</STitle>
            <div style={{ fontSize: 26, fontWeight: 900, color: 'var(--text)', fontFamily: 'var(--font-display)', marginBottom: 3 }}>{s.val}</div>
            <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: 9 }}>{s.sub}</div>
            <Bar pct={s.pct} color={s.color} />
          </Card>
        ))}
      </div>

      {/* Allocations + Rules */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 13, marginBottom: 13 }}>
        <Card>
          <STitle>Use-of-Funds Allocation</STitle>
          {TREASURY_ALLOCATIONS.map(a => (
            <div key={a.label} style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '7px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ width: 8, height: 8, borderRadius: 2, background: a.color, flexShrink: 0 }} />
              <div style={{ fontSize: 12, color: 'var(--text)', fontFamily: 'var(--font-body)', flex: 1 }}>{a.label}</div>
              <div style={{ flex: 2 }}><Bar pct={a.pct} color={a.color} /></div>
              <div style={{ fontSize: 10, color: a.color, fontFamily: 'var(--font-mono)', fontWeight: 700, width: 32, textAlign: 'right' }}>{a.pct}%</div>
            </div>
          ))}
        </Card>
        <Card>
          <STitle>Treasury Rules</STitle>
          {RULES.map(r => (
            <div key={r.title} style={{ display: 'flex', gap: 8, padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ width: 7, height: 7, borderRadius: '50%', background: r.color, marginTop: 4, flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', fontFamily: 'var(--font-display)', marginBottom: 2 }}>{r.title}</div>
                <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', lineHeight: 1.6 }}>{r.desc}</div>
              </div>
              <Tag label={r.status} color={r.color} />
            </div>
          ))}
        </Card>
      </div>

      {/* Admin: Disbursements */}
      {isAdmin && (
        <Card gradient="linear-gradient(135deg,#EDE9FE,#E0E7FF)">
          <STitle color="#6D28D9">Pending Disbursements</STitle>
          {DISB.map(d => (
            <div key={d.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 10, background: 'var(--panel)', marginBottom: 6, border: '1px solid var(--border)' }}>
              <Pill label={d.id} color="#6D28D9" />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--text)', fontFamily: 'var(--font-body)' }}>{d.desc}</div>
                <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginTop: 1 }}>By {d.req}</div>
              </div>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)', fontFamily: 'var(--font-mono)' }}>{d.amount}</div>
              <Tag label={`${d.sigs}/${d.need} SIGS`} color={d.sigs >= d.need ? '#059669' : '#D97706'} />
              <button style={{ padding: '5px 11px', borderRadius: 8, background: d.sigs >= d.need ? '#059669' : '#D97706', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 10, cursor: 'pointer' }}>{d.sigs >= d.need ? 'EXECUTE' : 'SIGN'}</button>
            </div>
          ))}
        </Card>
      )}
    </div>
  )
}
