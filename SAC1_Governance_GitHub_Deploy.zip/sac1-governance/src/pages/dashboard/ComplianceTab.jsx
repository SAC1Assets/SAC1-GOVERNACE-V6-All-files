/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
/**
 * pages/dashboard/ComplianceTab.jsx
 */
import { useState } from 'react'
import { useAuth } from '@/context/AuthContext'
import { Card, STitle, Tag, Pill, Toggle } from '@/components/ui'
import { COMPLIANCE_ITEMS } from '@/constants'

export default function ComplianceTab() {
  const { isAdmin } = useAuth()
  const [rules, setRules] = useState(COMPLIANCE_ITEMS)
  const rc = { HIGH: '#DC2626', MEDIUM: '#D97706', LOW: '#059669' }

  const toggle = (id) => {
    if (!isAdmin) return
    setRules(r => r.map(x => x.id === id ? { ...x, enabled: !x.enabled } : x))
    // API: PATCH /compliance/rules/:id/toggle
  }

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 11, marginBottom: 16 }}>
        {[
          { label: 'Active',       val: rules.filter(r => r.enabled).length,                       color: '#059669', bg: '#D1FAE5' },
          { label: 'Suspended',    val: rules.filter(r => !r.enabled).length,                      color: '#DC2626', bg: '#FEE2E2' },
          { label: 'High Risk',    val: rules.filter(r => r.risk === 'HIGH').length,               color: '#DC2626', bg: '#FEE2E2' },
          { label: 'Jurisdictions',val: [...new Set(rules.map(r => r.jurisdiction))].length,       color: '#6D28D9', bg: '#EDE9FE' },
        ].map(s => (
          <div key={s.label} style={{ background: `linear-gradient(135deg,${s.bg},#fff)`, borderRadius: 14, border: '1.5px solid var(--border)', padding: '13px 15px' }}>
            <STitle color={s.color}>{s.label}</STitle>
            <div style={{ fontSize: 28, fontWeight: 900, color: s.color, fontFamily: 'var(--font-display)' }}>{s.val}</div>
          </div>
        ))}
      </div>
      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 13 }}>
          <STitle>Regulatory Rules</STitle>
          <Tag label={isAdmin ? 'ADMIN — TOGGLES ON' : 'READ ONLY'} color={isAdmin ? '#6D28D9' : '#7B88B0'} />
        </div>
        {rules.map((r) => (
          <div key={r.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 10px', borderRadius: 10, marginBottom: 5, background: r.enabled ? 'var(--bg)' : 'rgba(220,38,38,.06)', border: `1px solid ${r.enabled ? 'var(--border)' : 'rgba(220,38,38,.22)'}` }}>
            <Toggle on={r.enabled} onChange={() => toggle(r.id)} disabled={!isAdmin} />
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 2, flexWrap: 'wrap' }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>{r.title}</span>
                <Tag label={r.risk} color={rc[r.risk]} />
                <Pill label={r.jurisdiction} color="#4338CA" />
              </div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', lineHeight: 1.6 }}>{r.desc}</div>
            </div>
            <Tag label={r.enabled ? 'ACTIVE' : 'SUSPENDED'} color={r.enabled ? '#059669' : '#DC2626'} />
          </div>
        ))}
      </Card>
    </div>
  )
}


/**
 * pages/dashboard/VotingTab.jsx
 */
import { useAuth } from '@/context/AuthContext'
import { useProposals, useVote } from '@/hooks/useGovernance'
import { Card, STitle, Tag, Pill, Bar } from '@/components/ui'
import { GOVERNANCE_RULES } from '@/constants'

const MOCK_PROPOSALS = [
  { id: 'GOV-007', title: 'Authorize $450K Technology Infrastructure — Q3 2026', proposer: 'Executive Committee', closes: 'May 15, 2026', for: 68, against: 12, abstain: 8, quorum: 88, qReq: 66, status: 'ACTIVE', voted: false },
  { id: 'GOV-008', title: 'African Corridor Activation — Ghana & Nigeria Phase 1', proposer: 'Business Development', closes: 'May 22, 2026', for: 51, against: 29, abstain: 5, quorum: 85, qReq: 66, status: 'ACTIVE', voted: false },
  { id: 'GOV-006', title: 'Ratify FAST Agreement Equity Pool — Advisor Program (0.75%)', proposer: 'Legal & Governance', closes: 'Apr 28, 2026', for: 79, against: 5, abstain: 4, quorum: 88, qReq: 66, status: 'PASSED', voted: true },
]

export function VotingTab() {
  const { isAdmin } = useAuth()
  const [proposals, setProps] = useState(MOCK_PROPOSALS)
  // const { data: proposals } = useProposals()   // ← uncomment when backend ready
  // const { mutate: castVote } = useVote()

  const cast = (id, choice) => {
    setProps(p => p.map(x => x.id !== id || x.voted || x.status !== 'ACTIVE' ? x : { ...x, voted: true, [choice]: x[choice] + 8 }))
    // castVote({ proposalId: id, choice })
  }

  const VRULES = [
    { title: 'Quorum Threshold',          desc: 'Minimum 66% of voting-weight tokens must participate.',  status: 'ACTIVE', color: '#059669' },
    { title: 'Simple Majority',            desc: '>50% of cast votes for operational decisions.',           status: 'ACTIVE', color: '#059669' },
    { title: 'Supermajority — Structural', desc: '≥75% required for token supply changes, amendments.',   status: 'ACTIVE', color: '#4338CA' },
    { title: 'Proposal Notice Period',     desc: '7-day notice before voting; emergency: 48hrs.',         status: 'ACTIVE', color: '#059669' },
    { title: 'Advisor Voting Weight',      desc: 'FAST advisors receive 0.5x weight during vesting.',     status: 'DRAFT',  color: '#D97706' },
  ]

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 13 }}>
      <div>
        <STitle>Proposals</STitle>
        {proposals.map(p => {
          const tot = p.for + p.against + p.abstain
          const fP = Math.round((p.for / tot) * 100)
          const aP = Math.round((p.against / tot) * 100)
          return (
            <Card key={p.id} style={{ marginBottom: 10 }}>
              <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 6, flexWrap: 'wrap' }}>
                <Pill label={p.id} color="#6D28D9" />
                <Tag label={p.status} color={p.status === 'PASSED' ? '#059669' : '#6D28D9'} />
                <Tag label={`QUORUM ${p.quorum}%`} color={p.quorum >= p.qReq ? '#059669' : '#D97706'} />
              </div>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text)', fontFamily: 'var(--font-display)', marginBottom: 3 }}>{p.title}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: 10 }}>By {p.proposer} · Closes {p.closes}</div>
              <div style={{ display: 'flex', height: 6, borderRadius: 3, overflow: 'hidden', gap: 2, marginBottom: 5 }}>
                <div style={{ width: `${fP}%`, background: '#059669', transition: 'width .8s' }} />
                <div style={{ width: `${aP}%`, background: '#DC2626' }} />
                <div style={{ flex: 1, background: 'var(--border)' }} />
              </div>
              <div style={{ display: 'flex', gap: 11, fontSize: 10, fontFamily: 'var(--font-mono)', marginBottom: 7 }}>
                <span style={{ color: '#059669' }}>▲ {fP}%</span>
                <span style={{ color: '#DC2626' }}>▼ {aP}%</span>
                <span style={{ color: 'var(--text-muted)' }}>— {100-fP-aP}%</span>
              </div>
              {!isAdmin && p.status === 'ACTIVE' && !p.voted && (
                <div style={{ display: 'flex', gap: 7, paddingTop: 8, borderTop: '1px solid var(--border)' }}>
                  {[['for','#059669','👍 For'],['against','#DC2626','👎 Against'],['abstain','#7B88B0','🤷 Abstain']].map(([k,c,l]) => (
                    <button key={k} onClick={() => cast(p.id, k)} style={{ padding: '7px 12px', borderRadius: 8, background: `${c}12`, border: `1.5px solid ${c}35`, color: c, fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 11, cursor: 'pointer' }}>{l}</button>
                  ))}
                </div>
              )}
              {p.voted && <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid var(--border)', fontSize: 10, color: '#059669', fontFamily: 'var(--font-mono)' }}>✓ VOTE RECORDED</div>}
            </Card>
          )
        })}
      </div>
      <Card>
        <STitle>Governance Rules</STitle>
        {VRULES.map(r => (
          <div key={r.title} style={{ display: 'flex', gap: 8, padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: r.color, marginTop: 4, flexShrink: 0 }} />
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', fontFamily: 'var(--font-display)', marginBottom: 2 }}>{r.title}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', lineHeight: 1.6 }}>{r.desc}</div>
              <div style={{ marginTop: 4 }}><Tag label={r.status} color={r.color} /></div>
            </div>
          </div>
        ))}
      </Card>
    </div>
  )
}

export default VotingTab


/**
 * pages/dashboard/StakingTab.jsx
 */
import { useState } from 'react'
import { Bar, Card, STitle } from '@/components/ui'
import { LOCK_PERIODS } from '@/constants'
import { usePrices } from '@/context/PriceContext'

export function StakingTab() {
  const { sac1 } = usePrices()
  const [selLock, setSel] = useState(LOCK_PERIODS[1])
  const [amt, setAmt]     = useState('')
  const st = 5000, lq = 7450, tot = st + lq

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 13, marginBottom: 18 }}>
        {[
          { label: 'Total SAC1', val: tot.toLocaleString(), sub: `≈ $${(tot * sac1.price).toFixed(2)} USD`, color: '#6D28D9', bg: '#EDE9FE' },
          { label: 'Staked',     val: st.toLocaleString(),  sub: '3-month lock active',                     color: '#059669', bg: '#D1FAE5' },
          { label: 'Liquid',     val: lq.toLocaleString(),  sub: 'Available to stake',                      color: '#4338CA', bg: '#E0E7FF' },
          { label: 'Gov. Weight',val: '1.25x',              sub: 'Current multiplier',                      color: '#B45309', bg: '#FEF3C7' },
        ].map(s => (
          <div key={s.label} style={{ background: `linear-gradient(135deg,${s.bg},#fff)`, borderRadius: 13, border: '1.5px solid var(--border)', padding: 16 }}>
            <STitle color={s.color}>{s.label}</STitle>
            <div style={{ fontSize: 24, fontWeight: 900, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>{s.val}</div>
            <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginTop: 2 }}>{s.sub}</div>
          </div>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 13 }}>
        <Card>
          <STitle>Choose Lock Period</STitle>
          {LOCK_PERIODS.map(lp => (
            <div key={lp.label} onClick={() => setSel(lp)}
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 13px', borderRadius: 10, marginBottom: 7, background: selLock.label === lp.label ? `${lp.color}10` : 'var(--bg-alt)', border: `1.5px solid ${selLock.label === lp.label ? lp.color : 'var(--border)'}`, cursor: 'pointer', transition: 'all .15s' }}>
              <div style={{ display: 'flex', gap: 9, alignItems: 'center' }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: lp.color }} />
                <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)', fontFamily: 'var(--font-body)' }}>{lp.label}</span>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 16, fontWeight: 900, color: lp.color, fontFamily: 'var(--font-mono)' }}>{lp.display}</div>
                <div style={{ fontSize: 8, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>weight</div>
              </div>
            </div>
          ))}
        </Card>
        <Card>
          <STitle>Stake SAC1 Tokens</STitle>
          <div style={{ marginBottom: 13 }}>
            <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: 5, textTransform: 'uppercase' }}>Amount to Stake</div>
            <div style={{ position: 'relative' }}>
              <input value={amt} onChange={e => setAmt(e.target.value)} type="number" placeholder="0"
                style={{ width: '100%', padding: '11px 58px 11px 13px', borderRadius: 10, background: 'var(--bg-alt)', border: '1.5px solid var(--border)', fontSize: 16, fontFamily: 'var(--font-mono)', color: 'var(--text)', boxSizing: 'border-box' }} />
              <span style={{ position: 'absolute', right: 11, top: '50%', transform: 'translateY(-50%)', fontSize: 9, color: 'var(--sac)', fontFamily: 'var(--font-mono)', fontWeight: 700 }}>SAC1</span>
            </div>
            {amt && <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginTop: 3 }}>≈ ${(parseFloat(amt || 0) * sac1.price).toFixed(2)} USD</div>}
          </div>
          <div style={{ padding: '12px', borderRadius: 10, background: `${selLock.color}10`, border: `1px solid ${selLock.color}25`, marginBottom: 13 }}>
            {[['Lock Period', selLock.label], ['Governance Weight', selLock.display], ['Effective Votes', amt ? `${Math.round(parseFloat(amt || 0) * selLock.multiplier).toLocaleString()} weight` : 'Enter amount']].map(([k, v]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', borderBottom: `1px solid ${selLock.color}15` }}>
                <span style={{ fontSize: 11, color: 'var(--text-med)', fontFamily: 'var(--font-body)' }}>{k}</span>
                <span style={{ fontSize: 12, fontWeight: 700, color: selLock.color, fontFamily: 'var(--font-mono)' }}>{v}</span>
              </div>
            ))}
          </div>
          <button style={{ width: '100%', padding: '12px', borderRadius: 11, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 13, cursor: 'pointer', boxShadow: 'var(--shadow-sac)' }}>
            🔒 Stake & Lock SAC1
          </button>
          <div style={{ marginTop: 9, padding: '8px 12px', borderRadius: 8, background: '#FEF3C7', border: '1px solid rgba(217,119,6,.25)', fontSize: 9, color: '#78350F', fontFamily: 'var(--font-mono)', lineHeight: 1.7 }}>⚠ Staked tokens lock for the selected period and cannot be unstaked early.</div>
        </Card>
      </div>
    </div>
  )
}

export default StakingTab
