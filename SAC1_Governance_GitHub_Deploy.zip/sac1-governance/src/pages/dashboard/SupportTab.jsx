/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useState } from 'react'
import { useAuth } from '@/context/AuthContext'
import { useTickets, useCreateTicket, useReplyTicket, useUpdateTicketStatus } from '@/hooks/useSupport'
import { Card, STitle, Tag, BackBtn } from '@/components/ui'
import { TICKET_CATEGORIES } from '@/constants'
import { TICKET_STATUS_META, TICKET_PRIORITY_META, fmtFull, fmtTime, fmtDate, generateTicketId } from '@/utils'

const MOCK_TICKETS = [
  { id: 'TKT-1001', number: 'TKT-1001', subject: 'SAC1 balance not reflected after transfer', category: 'Token Transfer', status: 'OPEN', priority: 'HIGH', createdAt: new Date(Date.now()-7200000), updatedAt: new Date(Date.now()-3600000), wallet: '0xAB12...34CD', messages: [{ from:'user', text:'I sent 500 SAC1 two hours ago but my balance has not updated.', time: new Date(Date.now()-7200000) }, { from:'admin', text:"We're investigating the delay. Please allow up to 15 minutes.", time: new Date(Date.now()-3600000) }] },
  { id: 'TKT-1002', number: 'TKT-1002', subject: 'Unable to cast vote on GOV-007', category: 'Voting Rights', status: 'IN PROGRESS', priority: 'MEDIUM', createdAt: new Date(Date.now()-18000000), updatedAt: new Date(Date.now()-1800000), wallet: '0xEF56...78GH', messages: [{ from:'user', text:'The Vote For button is greyed out on GOV-007.', time: new Date(Date.now()-18000000) }] },
  { id: 'TKT-1003', number: 'TKT-1003', subject: 'KYC verification stuck at Tier 1', category: 'Compliance Issue', status: 'RESOLVED', priority: 'LOW', createdAt: new Date(Date.now()-86400000), updatedAt: new Date(Date.now()-43200000), wallet: '0xIJ90...12KL', messages: [{ from:'user', text:'My KYC has been at Tier 1 for 3 days.', time: new Date(Date.now()-86400000) }, { from:'admin', text:'Your documents are verified. Tier 2 is now active.', time: new Date(Date.now()-43200000) }] },
]

export default function SupportTab() {
  const { isAdmin } = useAuth()
  const [tickets, setTix]  = useState(MOCK_TICKETS)
  const [view,    setView] = useState('list')   // 'list' | 'detail' | 'create'
  const [sel,     setSel]  = useState(null)
  const [reply,   setReply]= useState('')
  const [filter,  setFilt] = useState('ALL')
  const [form,    setForm] = useState({ subject:'', category: TICKET_CATEGORIES[0], priority:'MEDIUM', description:'' })

  const filtered = filter === 'ALL' ? tickets : tickets.filter(t => t.status === filter)

  const submit = () => {
    if (!form.subject || !form.description) return
    const id = generateTicketId()
    const t = { id, number: id, subject: form.subject, category: form.category, status: 'OPEN', priority: form.priority, createdAt: new Date(), updatedAt: new Date(), wallet: '0xGUEST', messages: [{ from:'user', text: form.description, time: new Date() }] }
    setTix(p => [t, ...p])
    setForm({ subject:'', category: TICKET_CATEGORIES[0], priority:'MEDIUM', description:'' })
    setView('list')
    // API: POST /support/tickets
  }

  const sendReply = (id) => {
    if (!reply.trim()) return
    setTix(p => p.map(t => t.id !== id ? t : { ...t, messages: [...t.messages, { from: isAdmin ? 'admin' : 'user', text: reply.trim(), time: new Date() }], updatedAt: new Date(), status: isAdmin && t.status === 'OPEN' ? 'IN PROGRESS' : t.status }))
    setReply('')
    // API: POST /support/tickets/:id/reply
  }

  if (view === 'create') return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 20 }}>
        <BackBtn onClick={() => setView('list')} label="Back" />
        <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>Create Support Ticket</div>
      </div>
      <Card style={{ maxWidth: 600 }}>
        {[['SUBJECT','text','subject','Brief description of your issue'],['DESCRIPTION','textarea','description','Describe your issue in detail…']].map(([label, type, key, ph]) => (
          <div key={key} style={{ marginBottom: 13 }}>
            <label style={{ display: 'block', fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '.14em', marginBottom: 4, textTransform: 'uppercase' }}>{label}</label>
            {type === 'textarea'
              ? <textarea value={form[key]} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} placeholder={ph} rows={4} style={{ width: '100%', padding: '10px 11px', borderRadius: 10, background: 'var(--bg-alt)', border: '1.5px solid var(--border)', fontSize: 13, fontFamily: 'var(--font-body)', color: 'var(--text)', resize: 'vertical', boxSizing: 'border-box' }} />
              : <input value={form[key]} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} placeholder={ph} style={{ width: '100%', padding: '10px 11px', borderRadius: 10, background: 'var(--bg-alt)', border: '1.5px solid var(--border)', fontSize: 13, fontFamily: 'var(--font-body)', color: 'var(--text)', boxSizing: 'border-box' }} />
            }
          </div>
        ))}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 11, marginBottom: 16 }}>
          {[['CATEGORY','category',TICKET_CATEGORIES],['PRIORITY','priority',['HIGH','MEDIUM','LOW']]].map(([label, key, opts]) => (
            <div key={key}>
              <label style={{ display: 'block', fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '.14em', marginBottom: 4, textTransform: 'uppercase' }}>{label}</label>
              <select value={form[key]} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} style={{ width: '100%', padding: '10px 11px', borderRadius: 10, background: 'var(--bg-alt)', border: '1.5px solid var(--border)', fontSize: 13, fontFamily: 'var(--font-body)', color: 'var(--text)' }}>
                {opts.map(o => <option key={o}>{o}</option>)}
              </select>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 9 }}>
          <button onClick={() => setView('list')} style={{ flex: 1, padding: 12, borderRadius: 10, background: 'var(--bg-alt)', border: 'none', color: 'var(--text-muted)', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Cancel</button>
          <button onClick={submit} style={{ flex: 2, padding: 12, borderRadius: 10, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 13, cursor: 'pointer', boxShadow: 'var(--shadow-sac)' }}>🎫 Submit Ticket</button>
        </div>
      </Card>
    </div>
  )

  if (view === 'detail' && sel) {
    const t = tickets.find(x => x.id === sel.id) ?? sel
    const sm = TICKET_STATUS_META[t.status] ?? TICKET_STATUS_META['OPEN']
    return (
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 16 }}>
          <BackBtn onClick={() => setView('list')} label="Back" />
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}><div style={{ fontSize: 16, fontWeight: 800, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>{t.subject}</div><Tag label={t.status} color={sm.color} bg={sm.bg} /></div>
            <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginTop: 2 }}>{t.number} · {t.category}</div>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 220px', gap: 13 }}>
          <Card>
            <STitle>Conversation</STitle>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 11, marginBottom: 14 }}>
              {t.messages.map((m, i) => (
                <div key={i} style={{ display: 'flex', gap: 9, alignItems: 'flex-start' }}>
                  <div style={{ width: 30, height: 30, borderRadius: '50%', background: m.from === 'admin' ? 'linear-gradient(135deg,var(--sac),var(--indigo))' : 'linear-gradient(135deg,var(--green),var(--teal))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, flexShrink: 0 }}>{m.from === 'admin' ? '🏛️' : '🪙'}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', gap: 7, alignItems: 'center', marginBottom: 3 }}>
                      <span style={{ fontSize: 11, fontWeight: 700, color: m.from === 'admin' ? 'var(--sac)' : 'var(--green)', fontFamily: 'var(--font-display)' }}>{m.from === 'admin' ? 'SAC1 Admin' : 'You'}</span>
                      <span style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{fmtFull(m.time)}</span>
                    </div>
                    <div style={{ padding: '9px 12px', borderRadius: m.from === 'admin' ? '3px 12px 12px 12px' : '12px 3px 12px 12px', background: m.from === 'admin' ? 'var(--sac-l)' : 'var(--green-l)', fontSize: 12, color: 'var(--text)', fontFamily: 'var(--font-body)', lineHeight: 1.6 }}>{m.text}</div>
                  </div>
                </div>
              ))}
            </div>
            {t.status !== 'CLOSED' && (
              <div style={{ borderTop: '1px solid var(--border)', paddingTop: 13 }}>
                <textarea value={reply} onChange={e => setReply(e.target.value)} placeholder={isAdmin ? 'Type admin reply…' : 'Type your message…'} rows={2} style={{ width: '100%', padding: '9px 11px', borderRadius: 10, background: 'var(--bg-alt)', border: '1.5px solid var(--border)', fontSize: 12, fontFamily: 'var(--font-body)', color: 'var(--text)', resize: 'none', boxSizing: 'border-box', marginBottom: 7 }} />
                <button onClick={() => sendReply(t.id)} style={{ padding: '9px 20px', borderRadius: 10, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12, cursor: 'pointer', boxShadow: 'var(--shadow-sac)' }}>{isAdmin ? 'Send Admin Reply ↑' : 'Send Reply ↑'}</button>
              </div>
            )}
          </Card>
          <div>
            <Card style={{ marginBottom: 9 }}>
              <STitle>Ticket Details</STitle>
              {[['Ticket #', t.number],['Category', t.category],['Opened', fmtFull(t.createdAt)],['Wallet', t.wallet]].map(([k,v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{k}</span>
                  <span style={{ fontSize: 10, color: 'var(--text)', fontFamily: 'var(--font-body)' }}>{v}</span>
                </div>
              ))}
            </Card>
            {isAdmin && (
              <Card gradient="linear-gradient(135deg,var(--sac-l),var(--indigo-l))">
                <STitle color="var(--sac)">Admin Actions</STitle>
                {[['IN PROGRESS','#4338CA'],['RESOLVED','#059669'],['CLOSED','#7B88B0']].map(([s,c]) => (
                  <button key={s} onClick={() => { setTix(p => p.map(x => x.id !== t.id ? x : {...x,status:s,updatedAt:new Date()})); setView('list') }} style={{ display: 'block', width: '100%', marginBottom: 6, padding: '8px 11px', borderRadius: 9, background: t.status===s?`${c}18`:'var(--panel)', border:`1.5px solid ${t.status===s?c:'var(--border)'}`, color: t.status===s?c:'var(--text-med)', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 11, cursor: 'pointer', textAlign: 'left' }}>Mark as {s}</button>
                ))}
              </Card>
            )}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>Support Tickets</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginTop: 2 }}>{tickets.length} total · {tickets.filter(t => t.status === 'OPEN').length} open</div>
        </div>
        {!isAdmin && <button onClick={() => setView('create')} style={{ padding: '9px 18px', borderRadius: 10, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12, cursor: 'pointer', boxShadow: 'var(--shadow-sac)' }}>🎫 Create Ticket</button>}
        {isAdmin && <div style={{ display: 'flex', gap: 6 }}>{['ALL','OPEN','IN PROGRESS','RESOLVED'].map(f => <button key={f} onClick={() => setFilt(f)} style={{ padding: '6px 12px', borderRadius: 8, background: filter===f?'var(--sac)':'var(--bg-alt)', border: `1.5px solid ${filter===f?'var(--sac)':'var(--border)'}`, color: filter===f?'#fff':'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: 9, fontWeight: 700, cursor: 'pointer' }}>{f}</button>)}</div>}
      </div>
      <Card>
        {filtered.map(t => {
          const sm = TICKET_STATUS_META[t.status] ?? TICKET_STATUS_META['OPEN']
          const pm = TICKET_PRIORITY_META[t.priority] ?? TICKET_PRIORITY_META.MEDIUM
          return (
            <div key={t.id} onClick={() => { setSel(t); setView('detail') }}
              style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '12px 12px', borderRadius: 10, marginBottom: 6, background: 'var(--bg)', border: '1.5px solid var(--border)', cursor: 'pointer' }}>
              <div style={{ width: 34, height: 34, borderRadius: 9, background: `${sm.color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, flexShrink: 0 }}>
                {t.status==='RESOLVED'?'✅':t.status==='CLOSED'?'🔒':t.status==='IN PROGRESS'?'⚙️':'🎫'}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2, flexWrap: 'wrap' }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>{t.subject}</span>
                  <Tag label={t.status} color={sm.color} bg={sm.bg} />
                  <Tag label={t.priority} color={pm.color} bg={pm.bg} />
                </div>
                <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{t.number} · {t.category} · {t.messages.length} msgs</div>
              </div>
              <div style={{ fontSize: 16, color: 'var(--text-muted)', flexShrink: 0 }}>›</div>
            </div>
          )
        })}
      </Card>
    </div>
  )
}
