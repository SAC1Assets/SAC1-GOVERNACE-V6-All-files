/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
// VotingTab.jsx - re-export from ComplianceTab.jsx
export { VotingTab as default } from './ComplianceTab'
