/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useState } from 'react'
import { Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import PriceTicker from '@/components/layout/PriceTicker'
import DashboardHeader from '@/components/layout/DashboardHeader'
import Sidebar from '@/components/layout/Sidebar'
import { ChatPanel } from '@/components/modals/Modals'
import { WalletModal } from '@/components/modals/Modals'
import { NavLink } from 'react-router-dom'

const TABS = [
  { to: '/dashboard/treasury',   label: '💰 Treasury'   },
  { to: '/dashboard/compliance', label: '🛡️ Compliance' },
  { to: '/dashboard/voting',     label: '🗳️ Voting'     },
  { to: '/dashboard/support',    label: '🎫 Support'    },
  { to: '/dashboard/staking',    label: '🔒 Staking'    },
]

export default function DashboardLayout() {
  const { isAdmin } = useAuth()
  const navigate    = useNavigate()
  const [wallet,    setWallet]  = useState(null)
  const [showW,     setShowW]   = useState(false)
  const [showChat,  setShowChat]= useState(false)
  const [locked,    setLocked]  = useState(false)

  const connectWallet = (name) => {
    const addr = '0x' + Math.random().toString(16).slice(2, 8).toUpperCase() + '...' + Math.random().toString(16).slice(2, 6).toUpperCase()
    setWallet({ name, address: addr })
    setShowW(false)
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      {showW   && <WalletModal onConnect={connectWallet} onClose={() => setShowW(false)} />}
      {showChat && <ChatPanel onClose={() => setShowChat(false)} />}

      {locked && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(18,24,48,.78)', backdropFilter: 'blur(10px)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 68, marginBottom: 13 }}>🔒</div>
            <div style={{ fontSize: 26, fontWeight: 900, color: '#fff', fontFamily: 'var(--font-display)', marginBottom: 7 }}>Dashboard Locked</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,.55)', fontFamily: 'var(--font-mono)' }}>Administrator has temporarily locked this dashboard.</div>
          </div>
        </div>
      )}

      <PriceTicker />
      <DashboardHeader
        onConnectWallet={() => setShowW(true)}
        wallet={wallet}
        onToggleLock={() => setLocked(p => !p)}
        locked={locked}
        isAdmin={isAdmin}
        onToggleChat={() => setShowChat(p => !p)}
        chatOpen={showChat}
      />

      {/* Tab nav */}
      <nav style={{ background: 'var(--panel)', borderBottom: '1.5px solid var(--border)', padding: '0 28px', display: 'flex', alignItems: 'center' }}>
        {TABS.map(t => (
          <NavLink key={t.to} to={t.to}
            style={({ isActive }) => ({
              padding: '11px 16px', fontSize: 11, fontWeight: isActive ? 700 : 400,
              fontFamily: 'var(--font-display)', color: isActive ? 'var(--green)' : 'var(--text-muted)',
              borderBottom: isActive ? '3px solid var(--green)' : '3px solid transparent',
              textDecoration: 'none', transition: 'color .15s',
            })}>
            {t.label}
          </NavLink>
        ))}
        <button onClick={() => navigate('/membership')}
          style={{ marginLeft: 'auto', padding: '6px 13px', borderRadius: 8, background: 'linear-gradient(135deg,#0F9B8E,#0F766E)', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 10, cursor: 'pointer', boxShadow: '0 3px 9px rgba(15,155,142,.35)', display: 'flex', alignItems: 'center', gap: 4 }}>
          🌍 Upgrade Seat
        </button>
      </nav>

      {/* Page content */}
      <main style={{ padding: '24px 28px', flex: 1, maxWidth: 1260 }}>
        <Outlet context={{ wallet, sac1Price: 0.2847 }} />
      </main>

      {/* Floating chat button */}
      <button onClick={() => setShowChat(p => !p)}
        style={{ position: 'fixed', bottom: 22, right: 22, width: 50, height: 50, borderRadius: '50%', background: showChat ? 'var(--sac-l)' : 'linear-gradient(135deg,var(--sac),var(--indigo))', border: showChat ? '2px solid var(--sac)' : 'none', color: showChat ? 'var(--sac)' : '#fff', fontSize: 19, cursor: 'pointer', boxShadow: showChat ? '0 4px 14px rgba(109,40,217,.25)' : 'var(--shadow-sac)', zIndex: 799, display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all .2s' }}>
        {showChat ? '✕' : '💬'}
      </button>
    </div>
  )
}
