/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useState } from 'react'
import { useOutletContext } from 'react-router-dom'
import { useUsers } from '@/hooks/useUsers'
import { Card, STitle, Tag, TierBadge, BackBtn, Spinner } from '@/components/ui'
import { fmtDate, truncateAddress } from '@/utils'

const MOCK_USERS = [
  { id:'USR-0001', name:'Amara Osei',       email:'amara.osei@email.com',    phone:'+233244123456', country:'Ghana',  username:'amara_osei',  tier:'governance', joined:'Jan 12, 2026', kyc:'TIER 2', status:'ACTIVE',   wallet:'0xA1B2...C3D4', sac1Balance:12450,  usdcBalance:3200,  votingWeight:18675, totalTxns:34, avatar:'🇬🇭' },
  { id:'USR-0002', name:'Kofi Mensah',      email:'kofi.mensah@email.com',   phone:'+234802345678', country:'Nigeria',username:'kofi_mensah', tier:'community',  joined:'Feb 3, 2026',  kyc:'TIER 1', status:'ACTIVE',   wallet:'0xE5F6...G7H8', sac1Balance:4800,   usdcBalance:750,   votingWeight:4800,  totalTxns:12, avatar:'🇳🇬' },
  { id:'USR-0003', name:'Fatima Al-Rashid', email:'fatima.alrashid@email.com',phone:'+12025551234', country:'USA',   username:'fatima_ar',   tier:'treasury',   joined:'Jan 28, 2026', kyc:'TIER 2', status:'ACTIVE',   wallet:'0xI9J0...K1L2', sac1Balance:28900,  usdcBalance:12500, votingWeight:57800, totalTxns:67, avatar:'🇺🇸' },
  { id:'USR-0004', name:'Emmanuel Asante',  email:'e.asante@email.com',      phone:'+233201234567', country:'Ghana', username:'e_asante',    tier:'governance', joined:'Mar 5, 2026',  kyc:'TIER 2', status:'SUSPENDED',wallet:null,           sac1Balance:8200,   usdcBalance:0,     votingWeight:12300, totalTxns:8,  avatar:'🇬🇭' },
  { id:'USR-0005', name:'Sarah Okafor',     email:'sarah.okafor@email.com',  phone:'+447911123456', country:'UK',    username:'sarah_ok',    tier:'community',  joined:'Apr 14, 2026', kyc:'TIER 1', status:'ACTIVE',   wallet:null,           sac1Balance:1800,   usdcBalance:200,   votingWeight:1800,  totalTxns:3,  avatar:'🇬🇧' },
]

const STATUS_COLORS = { ACTIVE: '#059669', SUSPENDED: '#DC2626', BANNED: '#7F1D1D', PENDING_KYC: '#D97706' }
const KYC_COLORS    = { 'TIER 2': '#059669', 'TIER 1': '#D97706', PENDING: '#DC2626' }

export default function AdminUsersTab() {
  const ctx = useOutletContext() || {}
  const { onSendToUser, sac1Price = 0.2847 } = ctx

  // const { data: users = [], isLoading } = useUsers()  // ← uncomment when backend ready
  const [users] = useState(MOCK_USERS)
  const [query,  setQuery]  = useState('')
  const [expanded, setExp]  = useState(null)

  const filtered = users.filter(u => {
    const q = query.toLowerCase()
    return !q || [u.name, u.email, u.username, u.country, u.id]
      .some(s => s?.toLowerCase().includes(q))
  })

  if (expanded) return (
    <div>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:18 }}>
        <BackBtn onClick={() => setExp(null)} label="Back to Users" />
        <div style={{ flex:1 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
            <span style={{ fontSize:19, fontWeight:800, color:'var(--text)', fontFamily:'var(--font-display)' }}>{expanded.avatar} {expanded.name}</span>
            <Tag label={expanded.status} color={STATUS_COLORS[expanded.status] || '#7B88B0'} />
            <Tag label={`KYC ${expanded.kyc}`} color={KYC_COLORS[expanded.kyc] || '#7B88B0'} />
            <TierBadge tier={expanded.tier} />
          </div>
          <div style={{ fontSize:9, color:'var(--text-muted)', fontFamily:'var(--font-mono)', marginTop:3 }}>{expanded.id} · {expanded.email}</div>
        </div>
        {onSendToUser && (
          <button onClick={() => onSendToUser(expanded)}
            style={{ padding:'7px 14px', borderRadius:9, background:'linear-gradient(135deg,var(--sac),var(--indigo))', border:'none', color:'#fff', fontFamily:'var(--font-display)', fontWeight:700, fontSize:11, cursor:'pointer', boxShadow:'var(--shadow-sac)', display:'flex', alignItems:'center', gap:5 }}>
            ⟁ Send SAC1
          </button>
        )}
      </div>
      <Card>
        <STitle>Registered Profile</STitle>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0 28px' }}>
          {[
            ['User ID',       expanded.id],
            ['Full Name',     expanded.name],
            ['Email',         expanded.email],
            ['Phone',         expanded.phone || '—'],
            ['Country',       expanded.country],
            ['Username',      `@${expanded.username}`],
            ['Tier',          expanded.tier],
            ['KYC Level',     expanded.kyc],
            ['Status',        expanded.status],
            ['Joined',        expanded.joined],
            ['SAC1 Balance',  `${expanded.sac1Balance.toLocaleString()} SAC1 ≈ $${(expanded.sac1Balance * sac1Price).toFixed(2)}`],
            ['USDC Balance',  `$${expanded.usdcBalance.toLocaleString()}`],
            ['Voting Weight', expanded.votingWeight.toLocaleString()],
            ['Wallet',        expanded.wallet || '— Not connected'],
            ['Total Txns',    expanded.totalTxns.toString()],
          ].map(([k, v]) => (
            <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'7px 0', borderBottom:'1px solid var(--border)' }}>
              <span style={{ fontSize:9, color:'var(--text-muted)', fontFamily:'var(--font-mono)' }}>{k}</span>
              <span style={{ fontSize:11, color:'var(--text)', fontFamily:'var(--font-body)', fontWeight:500, maxWidth:220, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{v}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )

  return (
    <div>
      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
        <div>
          <div style={{ fontSize:20, fontWeight:800, color:'var(--text)', fontFamily:'var(--font-display)' }}>Registered Users</div>
          <div style={{ fontSize:10, color:'var(--text-muted)', fontFamily:'var(--font-mono)', marginTop:2 }}>
            {users.length} accounts · {users.filter(u => u.status==='ACTIVE').length} active
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:11, marginBottom:14 }}>
        {[
          { label:'Total',       val:users.length,                                               color:'#6D28D9', bg:'#EDE9FE' },
          { label:'Active',      val:users.filter(u=>u.status==='ACTIVE').length,                color:'#059669', bg:'#D1FAE5' },
          { label:'Community',   val:users.filter(u=>u.tier==='community').length,               color:'#0F9B8E', bg:'#CCFBF1' },
          { label:'Gov+ Tiers',  val:users.filter(u=>['governance','treasury','founding'].includes(u.tier)).length, color:'#6D28D9', bg:'#EDE9FE' },
          { label:'Total SAC1',  val:users.reduce((a,u)=>a+u.sac1Balance,0).toLocaleString(),   color:'#B45309', bg:'#FEF3C7' },
        ].map(s => (
          <div key={s.label} style={{ background:`linear-gradient(135deg,${s.bg},#fff)`, borderRadius:12, border:'1.5px solid var(--border)', padding:'13px 15px' }}>
            <div style={{ fontSize:10, letterSpacing:'.2em', color:s.color, textTransform:'uppercase', fontFamily:'var(--font-mono)', fontWeight:700, marginBottom:8 }}>{s.label}</div>
            <div style={{ fontSize:20, fontWeight:900, color:s.color, fontFamily:'var(--font-display)' }}>{s.val}</div>
          </div>
        ))}
      </div>

      {/* Search */}
      <div style={{ position:'relative', marginBottom:12 }}>
        <span style={{ position:'absolute', left:14, top:'50%', transform:'translateY(-50%)', fontSize:14, opacity:.3 }}>🔍</span>
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search by name, email, username, ID, country…"
          style={{ width:'100%', padding:'11px 40px 11px 42px', borderRadius:12, background:'var(--panel)', border:`2px solid ${query?'var(--sac)':'var(--border)'}`, fontSize:13, fontFamily:'var(--font-body)', color:'var(--text)', boxSizing:'border-box', transition:'border-color .2s' }} />
        {query && <button onClick={() => setQuery('')} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'var(--bg-alt)', border:'none', borderRadius:'50%', width:22, height:22, cursor:'pointer', fontSize:11, color:'var(--text-muted)' }}>✕</button>}
      </div>
      <div style={{ fontSize:9, color:'var(--text-muted)', fontFamily:'var(--font-mono)', marginBottom:9, textAlign:'right' }}>{filtered.length} of {users.length} users</div>

      {/* Table */}
      <div style={{ background:'var(--panel)', borderRadius:13, border:'1.5px solid var(--border)', overflow:'hidden' }}>
        {/* Table header */}
        <div style={{ display:'grid', gridTemplateColumns:'1.6fr 1.6fr 1fr 1fr 1fr 1fr 1fr 72px', padding:'8px 14px', background:'linear-gradient(90deg,#EDE9FE,var(--bg-alt))', borderBottom:'1.5px solid var(--border)' }}>
          {['Name','Email','Phone','Country','Username','Tier','Status',''].map((h,i) => (
            <div key={i} style={{ fontSize:9, color:'var(--text-muted)', fontFamily:'var(--font-mono)', letterSpacing:'.12em', textTransform:'uppercase', fontWeight:700 }}>{h}</div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div style={{ textAlign:'center', padding:'32px 0', color:'var(--text-muted)', fontFamily:'var(--font-body)' }}>No users found.</div>
        )}

        {filtered.map((u, i) => (
          <div key={u.id} style={{ display:'grid', gridTemplateColumns:'1.6fr 1.6fr 1fr 1fr 1fr 1fr 1fr 72px', padding:'11px 14px', borderBottom: i < filtered.length-1 ? '1px solid var(--border)':'none', alignItems:'center', background: i%2===0?'var(--panel)':'var(--bg)' }}>
            <div style={{ display:'flex', alignItems:'center', gap:7 }}>
              <span style={{ fontSize:14 }}>{u.avatar}</span>
              <div>
                <div style={{ fontSize:11, fontWeight:700, color:'var(--text)', fontFamily:'var(--font-display)' }}>{u.name}</div>
                <div style={{ fontSize:9, color:'var(--text-muted)', fontFamily:'var(--font-mono)' }}>{u.id}</div>
              </div>
            </div>
            <div style={{ fontSize:9, color:'var(--text-muted)', fontFamily:'var(--font-mono)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{u.email}</div>
            <div style={{ fontSize:9, color:'var(--text-muted)', fontFamily:'var(--font-mono)' }}>{u.phone || '—'}</div>
            <div style={{ fontSize:10, color:'var(--text)', fontFamily:'var(--font-body)' }}>{u.country}</div>
            <div style={{ fontSize:9, color:'var(--text-med)', fontFamily:'var(--font-mono)' }}>@{u.username}</div>
            <div><TierBadge tier={u.tier} /></div>
            <div><Tag label={u.status} color={STATUS_COLORS[u.status] || '#7B88B0'} /></div>
            <button onClick={() => setExp(u)} style={{ padding:'4px 11px', borderRadius:8, background:'linear-gradient(135deg,var(--sac),var(--indigo))', border:'none', color:'#fff', fontFamily:'var(--font-display)', fontWeight:700, fontSize:9, cursor:'pointer', whiteSpace:'nowrap' }}>View →</button>
          </div>
        ))}
      </div>

      <div style={{ marginTop:9, padding:'9px 13px', borderRadius:8, background:'var(--sac-l)', border:'1px solid rgba(109,40,217,.2)', fontSize:9, color:'var(--sac)', fontFamily:'var(--font-mono)', lineHeight:1.8 }}>
        📊 User data from API. New accounts created via Sign Up appear here in real-time. Production: PostgreSQL via FastAPI backend.
      </div>
    </div>
  )
}
