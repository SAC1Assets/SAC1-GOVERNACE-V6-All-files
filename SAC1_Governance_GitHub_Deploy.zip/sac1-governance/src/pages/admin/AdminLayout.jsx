/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useState } from 'react'
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import PriceTicker from '@/components/layout/PriceTicker'
import DashboardHeader from '@/components/layout/DashboardHeader'
import { SendSAC1Modal } from '@/components/modals/Modals'
import { usePrices } from '@/context/PriceContext'

const ADMIN_TABS = [
  { to: '/admin/treasury',   label: '💰 Treasury'      },
  { to: '/admin/compliance', label: '🛡️ Compliance'    },
  { to: '/admin/voting',     label: '🗳️ Voting'        },
  { to: '/admin/support',    label: '🎫 Support Inbox' },
  { to: '/admin/users',      label: '👤 Users'         },
]

export default function AdminLayout() {
  const { user, logout } = useAuth()
  const { sac1 } = usePrices()
  const navigate = useNavigate()
  const [showSend,  setShowSend]  = useState(false)
  const [sendTarget,setSendTarget]= useState(null)
  const [locked,    setLocked]    = useState(false)

  const handleLogout = async () => {
    await logout()
    navigate('/')
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      {showSend && (
        <SendSAC1Modal
          onClose={() => { setShowSend(false); setSendTarget(null) }}
          onSend={(data) => console.warn('SAC1 transfer:', data)}
          walletAddress="0xADMIN...TREASURY"
          sac1Price={sac1.price}
          prefillWallet={sendTarget?.wallet_address}
          prefillName={sendTarget?.name}
        />
      )}

      {locked && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(18,24,48,.85)', backdropFilter: 'blur(12px)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 72, marginBottom: 14 }}>🔒</div>
            <div style={{ fontSize: 26, fontWeight: 900, color: '#fff', fontFamily: 'var(--font-display)', marginBottom: 8 }}>Dashboard Locked</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,.5)', fontFamily: 'var(--font-mono)' }}>Token holder dashboard access temporarily suspended.</div>
            <button onClick={() => setLocked(false)} style={{ marginTop: 20, padding: '10px 22px', borderRadius: 10, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
              Unlock Dashboard
            </button>
          </div>
        </div>
      )}

      <PriceTicker />
      <DashboardHeader
        wallet={null}
        onConnectWallet={() => {}}
        onToggleLock={() => setLocked(p => !p)}
        locked={locked}
        isAdmin
        onToggleChat={() => {}}
        chatOpen={false}
      />

      {/* Admin tab nav */}
      <nav style={{ background: 'var(--panel)', borderBottom: '1.5px solid var(--border)', padding: '0 28px', display: 'flex', alignItems: 'center', gap: 2 }}>
        {ADMIN_TABS.map(t => (
          <NavLink key={t.to} to={t.to}
            style={({ isActive }) => ({
              padding: '11px 16px', fontSize: 11, fontWeight: isActive ? 700 : 400,
              fontFamily: 'var(--font-display)', color: isActive ? 'var(--sac)' : 'var(--text-muted)',
              borderBottom: isActive ? '3px solid var(--sac)' : '3px solid transparent',
              textDecoration: 'none', transition: 'color .15s', whiteSpace: 'nowrap',
            })}>
            {t.label}
          </NavLink>
        ))}

        {/* Send SAC1 quick action */}
        <button onClick={() => setShowSend(true)}
          style={{ marginLeft: 'auto', padding: '6px 14px', borderRadius: 8, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 10, cursor: 'pointer', boxShadow: 'var(--shadow-sac)', display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap' }}>
          ⟁ Send SAC1
        </button>
      </nav>

      <main style={{ padding: '24px 28px', flex: 1, maxWidth: 1340 }}>
        <Outlet context={{ onSendToUser: (user) => { setSendTarget(user); setShowSend(true) }, sac1Price: sac1.price }} />
      </main>
    </div>
  )
}
