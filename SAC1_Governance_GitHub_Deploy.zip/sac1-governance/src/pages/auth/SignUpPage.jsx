/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
/**
 * pages/auth/SignUpPage.jsx
 */
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { BackBtn } from '@/components/ui'
import TwoFactorModal from '@/components/modals/TwoFactorModal'
import { Field, ErrBox, PrimaryBtn } from './HolderLogin'

const COUNTRIES = ['Ghana','Nigeria','USA','UK','Liberia','Kenya','South Africa','Canada','Germany','France','UAE','Other']

export default function SignUpPage() {
  const navigate = useNavigate()
  const { register, verify2FA } = useAuth()
  const [form, setForm]   = useState({ name:'',email:'',phone:'',country:'',username:'',password:'',confirm:'' })
  const [errs, setErrs]   = useState({})
  const [showP, setShowP] = useState(false)
  const [showC, setShowC] = useState(false)
  const [step, setStep]   = useState('form')   // 'form' | '2fa'

  const f = (k, v) => { setForm(p => ({ ...p, [k]: v })); setErrs(p => ({ ...p, [k]: '' })) }

  const validate = () => {
    const e = {}
    if (!form.name.trim())             e.name     = 'Full name required'
    if (!form.email.includes('@'))     e.email    = 'Valid email required'
    if (form.phone.length < 6)        e.phone    = 'Valid phone required'
    if (!form.country)                 e.country  = 'Select your country'
    if (form.username.length < 3)     e.username = 'Min 3 characters'
    if (form.password.length < 8)     e.password = 'Min 8 characters'
    if (form.password !== form.confirm) e.confirm = "Passwords don't match"
    return e
  }

  const handleSubmit = async () => {
    const e = validate(); if (Object.keys(e).length) { setErrs(e); return }
    try {
      await register(form)
      setStep('2fa')
    } catch (err) {
      setErrs({ email: err.displayMessage || 'Registration failed' })
    }
  }

  const handle2FA = async (code) => {
    await verify2FA(code)
    navigate('/dashboard/treasury')
  }

  if (step === '2fa') return <TwoFactorModal email={form.email} onSuccess={handle2FA} onBack={() => setStep('form')} />

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', fontFamily: 'var(--font-body)' }}>
      <div style={{ background: 'linear-gradient(135deg,var(--sac-d),var(--sac))', padding: '16px 28px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(255,255,255,.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17, fontWeight: 900, color: '#fff', fontFamily: 'var(--font-display)' }}>S</div>
        <div>
          <div style={{ fontSize: 15, fontWeight: 800, color: '#fff', fontFamily: 'var(--font-display)' }}>SAC1 Governance</div>
          <div style={{ fontSize: 9, color: 'rgba(255,255,255,.55)', fontFamily: 'var(--font-mono)', letterSpacing: '.16em' }}>SABLEASENT COIN CORPORATION</div>
        </div>
      </div>

      <div style={{ maxWidth: 560, margin: '0 auto', padding: '32px 24px' }}>
        <div style={{ marginBottom: 22 }}><BackBtn onClick={() => navigate('/')} label="Back" /></div>
        <div style={{ background: 'var(--panel)', borderRadius: 'var(--radius-xl)', border: '1.5px solid var(--border)', padding: '30px 28px', boxShadow: 'var(--shadow-md)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 24, padding: '12px 16px', borderRadius: 10, background: 'linear-gradient(135deg,var(--sac-l),var(--indigo-l))' }}>
            <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'linear-gradient(135deg,var(--sac),var(--indigo))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🌍</div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--sac)', fontFamily: 'var(--font-display)' }}>Create Your Governance Account</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>Step 1 — Your Details · Step 2 — Verify Email (2FA)</div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 12px' }}>
            <div style={{ gridColumn: '1/-1' }}><Field icon="👤" value={form.name} onChange={v => f('name',v)} placeholder="e.g. Amara Osei" label="FULL NAME" />{errs.name && <ErrBox msg={errs.name}/>}</div>
            <div><Field icon="📧" value={form.email} onChange={v => f('email',v)} placeholder="you@email.com" label="EMAIL" type="email" />{errs.email && <ErrBox msg={errs.email}/>}</div>
            <div><Field icon="📱" value={form.phone} onChange={v => f('phone',v)} placeholder="+1 555 000 0000" label="PHONE" />{errs.phone && <ErrBox msg={errs.phone}/>}</div>
            <div style={{ gridColumn: '1/-1', marginBottom: 12 }}>
              <label style={{ display: 'block', fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '.14em', marginBottom: 5, textTransform: 'uppercase' }}>COUNTRY</label>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 14, opacity: .35, zIndex: 1 }}>🌍</span>
                <select value={form.country} onChange={e => f('country', e.target.value)} style={{ width: '100%', padding: '11px 11px 11px 38px', borderRadius: 11, background: errs.country ? 'var(--red-l)' : 'var(--bg-alt)', border: `1.5px solid ${errs.country ? 'var(--red)' : 'var(--border)'}`, fontSize: 13, fontFamily: 'var(--font-body)', color: form.country ? 'var(--text)' : 'var(--text-muted)' }}>
                  <option value="">Select country…</option>
                  {COUNTRIES.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              {errs.country && <ErrBox msg={errs.country}/>}
            </div>
            <div style={{ gridColumn: '1/-1' }}><Field icon="🔤" value={form.username} onChange={v => f('username',v)} placeholder="e.g. amara_osei" label="USERNAME" />{errs.username && <ErrBox msg={errs.username}/>}</div>
            <div><Field icon="🔑" value={form.password} onChange={v => f('password',v)} placeholder="Min 8 chars" label="PASSWORD" type={showP ? 'text' : 'password'} toggle={() => setShowP(p => !p)} showing={showP} />{errs.password && <ErrBox msg={errs.password}/>}</div>
            <div><Field icon="🔒" value={form.confirm} onChange={v => f('confirm',v)} placeholder="Re-enter" label="CONFIRM PASSWORD" type={showC ? 'text' : 'password'} toggle={() => setShowC(p => !p)} showing={showC} />{errs.confirm && <ErrBox msg={errs.confirm}/>}</div>
          </div>

          <div style={{ padding: '10px 14px', borderRadius: 8, background: 'var(--sac-l)', border: '1px solid rgba(109,40,217,.25)', marginBottom: 18, marginTop: 4 }}>
            <div style={{ fontSize: 10, color: 'var(--sac)', fontFamily: 'var(--font-mono)', lineHeight: 1.7 }}>🔐 After submitting, a 6-digit verification code will be sent to your email. Enter it to activate your account.</div>
          </div>
          <PrimaryBtn onClick={handleSubmit} label="Create Account → Verify Email" />
        </div>
        <div style={{ padding: '10px 14px', borderRadius: 8, background: 'var(--bg-alt)', border: '1px solid var(--border)', marginTop: 12, fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', lineHeight: 1.8 }}>⚖️ SAC1 grants governance rights — not investment returns. By signing up you agree to our Governance Participation Agreement.</div>
      </div>
    </div>
  )
}
