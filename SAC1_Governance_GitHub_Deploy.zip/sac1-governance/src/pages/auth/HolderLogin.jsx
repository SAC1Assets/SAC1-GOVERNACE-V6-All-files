/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
/**
 * pages/auth/HolderLogin.jsx
 * Token Holder login: username/email + password + forgot password + → 2FA
 */
import { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { BackBtn, Spinner } from '@/components/ui'
import TwoFactorModal from '@/components/modals/TwoFactorModal'
import toast from 'react-hot-toast'

export default function HolderLogin() {
  const navigate = useNavigate()
  const { loginHolder, verify2FA } = useAuth()
  const [uname, setUname]     = useState('')
  const [pwd,   setPwd]       = useState('')
  const [showP, setShowP]     = useState(false)
  const [error, setError]     = useState('')
  const [loading, setLoad]    = useState(false)
  const [shake, setShake]     = useState(false)
  const [forgot, setForgot]   = useState(false)
  const [fEmail, setFEmail]   = useState('')
  const [fSent,  setFSent]    = useState(false)
  const [step,   setStep]     = useState('login')   // 'login' | '2fa'
  const [tfEmail, setTfEmail] = useState('')
  const ref = useRef(null)
  useEffect(() => { ref.current?.focus() }, [])

  const trig = () => { setShake(true); setTimeout(() => setShake(false), 500) }

  const handleLogin = async () => {
    if (!uname || !pwd) { setError('Enter username and password.'); trig(); return }
    setLoad(true); setError('')
    try {
      const res = await loginHolder(uname.trim(), pwd)
      if (res.requires2FA) { setTfEmail(res.email); setStep('2fa') }
      else navigate('/dashboard/treasury')
    } catch (err) {
      setError(err.displayMessage || 'Invalid username or password.')
      setPwd(''); trig()
    } finally { setLoad(false) }
  }

  const handle2FA = async (code) => {
    await verify2FA(code)
    navigate('/dashboard/treasury')
  }

  const handleForgot = async () => {
    if (!fEmail.includes('@')) { setError('Enter a valid email.'); return }
    setLoad(true)
    // POST /auth/forgot-password handled by backend
    await new Promise(r => setTimeout(r, 1200))
    setLoad(false); setFSent(true)
  }

  if (step === '2fa') return <TwoFactorModal email={tfEmail} onSuccess={handle2FA} onBack={() => setStep('login')} />

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-body)' }}>
      <div style={{ width: '100%', maxWidth: 420, padding: '0 22px' }}>
        <div style={{ marginBottom: 22 }}><BackBtn onClick={() => navigate('/')} label="Back" /></div>

        <div style={{ background: 'var(--panel)', borderRadius: 'var(--radius-xl)', border: '1.5px solid var(--border)', padding: '34px 30px', boxShadow: 'var(--shadow-md)', animation: shake ? 'shake .4s ease' : 'slideIn .3s ease' }}>
          <div style={{ textAlign: 'center', marginBottom: 24 }}>
            <div style={{ width: 54, height: 54, borderRadius: 15, background: 'linear-gradient(135deg,var(--green),var(--teal))', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 13px', fontSize: 24, boxShadow: '0 6px 20px rgba(5,150,105,.4)' }}>🪙</div>
            <div style={{ fontSize: 22, fontWeight: 900, color: 'var(--text)', fontFamily: 'var(--font-display)', marginBottom: 3 }}>{forgot ? 'Reset Password' : 'Member Login'}</div>
            <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>SAC1 GOVERNANCE · TOKEN HOLDER</div>
          </div>

          {!forgot ? (
            <>
              {error && <ErrBox msg={error} />}
              <Field icon="👤" value={uname} onChange={v => { setUname(v); setError('') }} onEnter={handleLogin} placeholder="Username or email" label="USERNAME OR EMAIL" />
              <Field icon="🔑" value={pwd} onChange={v => { setPwd(v); setError('') }} onEnter={handleLogin} placeholder="Password" type={showP ? 'text' : 'password'} label="PASSWORD" toggle={() => setShowP(p => !p)} showing={showP} />
              <div style={{ textAlign: 'right', marginBottom: 16 }}>
                <button onClick={() => { setForgot(true); setError('') }} style={LinkBtn}>Forgot password?</button>
              </div>
              <PrimaryBtn onClick={handleLogin} loading={loading} label="Log In →" color="var(--green)" shadow="rgba(5,150,105,.4)" />
              <div style={{ textAlign: 'center', paddingTop: 13, borderTop: '1px solid var(--border)', marginTop: 13 }}>
                <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>No account? </span>
                <button onClick={() => navigate('/signup')} style={LinkBtn}>Sign Up →</button>
              </div>
            </>
          ) : fSent ? (
            <div style={{ textAlign: 'center', padding: '18px 0' }}>
              <div style={{ fontSize: 38, marginBottom: 11 }}>📧</div>
              <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--green)', fontFamily: 'var(--font-display)', marginBottom: 7 }}>Reset Email Sent!</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.7 }}>If an account exists for <strong>{fEmail}</strong>, you'll receive reset instructions.</div>
              <button onClick={() => { setForgot(false); setFSent(false); setFEmail('') }} style={{ ...PrimaryBtnStyle, marginTop: 16, width: 'auto', padding: '10px 22px' }}>Back to Login</button>
            </div>
          ) : (
            <>
              <div style={{ fontSize: 13, color: 'var(--text-med)', lineHeight: 1.6, marginBottom: 14 }}>Enter your registered email to receive a reset link.</div>
              {error && <ErrBox msg={error} />}
              <Field icon="📧" value={fEmail} onChange={v => { setFEmail(v); setError('') }} placeholder="your@email.com" label="REGISTERED EMAIL" />
              <PrimaryBtn onClick={handleForgot} loading={loading} label="Send Reset Link" />
              <button onClick={() => { setForgot(false); setError('') }} style={{ width: '100%', padding: 11, borderRadius: 12, background: 'var(--bg-alt)', border: 'none', color: 'var(--text-muted)', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, cursor: 'pointer', marginTop: 8 }}>← Back to Login</button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Shared sub-components used by auth pages ─────────────────────────────────
export function Field({ icon, value, onChange, onEnter, placeholder, label, type = 'text', toggle, showing }) {
  return (
    <div style={{ marginBottom: 12 }}>
      {label && <label style={{ display: 'block', fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '.14em', marginBottom: 5, textTransform: 'uppercase' }}>{label}</label>}
      <div style={{ position: 'relative' }}>
        {icon && <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 14, opacity: .35 }}>{icon}</span>}
        <input value={value} onChange={e => onChange(e.target.value)} onKeyDown={e => e.key === 'Enter' && onEnter?.()} type={type} placeholder={placeholder}
          style={{ width: '100%', padding: `12px ${toggle ? '40px' : '12px'} 12px ${icon ? '38px' : '12px'}`, borderRadius: 11, background: 'var(--bg-alt)', border: '1.5px solid var(--border)', fontSize: 13, fontFamily: 'var(--font-body)', color: 'var(--text)', boxSizing: 'border-box' }} />
        {toggle && <button type="button" onClick={toggle} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, opacity: .4, padding: 0 }}>{showing ? '🙈' : '👁️'}</button>}
      </div>
    </div>
  )
}

export function ErrBox({ msg }) {
  return <div style={{ padding: '9px 13px', borderRadius: 9, background: 'var(--red-l)', border: '1px solid rgba(220,38,38,.3)', marginBottom: 14, fontSize: 11, color: 'var(--red)', fontFamily: 'var(--font-mono)' }}>⚠ {msg}</div>
}

export function PrimaryBtn({ onClick, loading, label, color, shadow }) {
  return (
    <button onClick={onClick} disabled={loading}
      style={{ ...PrimaryBtnStyle, background: color ? `linear-gradient(135deg,${color},${color}cc)` : 'linear-gradient(135deg,var(--sac),var(--indigo))', boxShadow: shadow ? `0 6px 20px ${shadow}` : 'var(--shadow-sac)' }}>
      {loading ? <><Spinner size={14} /> Loading…</> : label}
    </button>
  )
}

const PrimaryBtnStyle = { width: '100%', padding: '13px', borderRadius: 12, border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 14, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 13 }
const LinkBtn = { background: 'none', border: 'none', cursor: 'pointer', fontSize: 12, color: 'var(--sac)', fontFamily: 'var(--font-body)', fontWeight: 600 }
