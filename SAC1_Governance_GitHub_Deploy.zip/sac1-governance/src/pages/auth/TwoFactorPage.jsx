/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
/**
 * pages/auth/TwoFactorPage.jsx
 * Standalone route — used if navigated to directly (e.g. after email link)
 */
import { useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import TwoFactorModal from '@/components/modals/TwoFactorModal'

export default function TwoFactorPage() {
  const navigate  = useNavigate()
  const { state } = useLocation()
  const { verify2FA, pendingEmail, role } = useAuth()

  const email  = state?.email  ?? pendingEmail ?? 'your email'
  const isDark = state?.dark   ?? false
  const dest   = state?.dest   ?? '/dashboard/treasury'

  const handle = async (code) => {
    await verify2FA(code)
    navigate(dest, { replace: true })
  }

  return (
    <TwoFactorModal
      email={email}
      dark={isDark}
      onSuccess={handle}
      onBack={() => navigate(-1)}
    />
  )
}


/**
 * pages/auth/ForgotPassword.jsx
 * Standalone forgot password page
 */
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { BackBtn } from '@/components/ui'
import { Field, ErrBox, PrimaryBtn } from './HolderLogin'
import api from '@/services/api'
import { ENDPOINTS } from '@/constants'

export function ForgotPassword() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [error, setError] = useState('')
  const [sent,  setSent]  = useState(false)
  const [load,  setLoad]  = useState(false)

  const submit = async () => {
    if (!email.includes('@')) { setError('Enter a valid email address.'); return }
    setLoad(true)
    try {
      await api.post(ENDPOINTS.AUTH_FORGOT_PASSWORD, { email })
      setSent(true)
    } catch (err) {
      setError(err.displayMessage || 'Something went wrong.')
    } finally { setLoad(false) }
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-body)' }}>
      <div style={{ width: '100%', maxWidth: 420, padding: '0 22px' }}>
        <div style={{ marginBottom: 22 }}><BackBtn onClick={() => navigate('/login')} label="Back to Login" /></div>
        <div style={{ background: 'var(--panel)', borderRadius: 20, border: '1.5px solid var(--border)', padding: '34px 30px', boxShadow: 'var(--shadow-md)' }}>
          {sent ? (
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 48, marginBottom: 14 }}>📧</div>
              <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--green)', fontFamily: 'var(--font-display)', marginBottom: 8 }}>Check your email</div>
              <div style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.7 }}>If <strong>{email}</strong> is registered, you'll receive a reset link shortly.</div>
              <button onClick={() => navigate('/login')} style={{ marginTop: 20, padding: '10px 22px', borderRadius: 11, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>Back to Login</button>
            </div>
          ) : (
            <>
              <div style={{ textAlign: 'center', marginBottom: 22 }}>
                <div style={{ fontSize: 38, marginBottom: 10 }}>🔑</div>
                <div style={{ fontSize: 20, fontWeight: 900, color: 'var(--text)', fontFamily: 'var(--font-display)', marginBottom: 4 }}>Forgot Password</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-body)' }}>Enter your email to receive a reset link</div>
              </div>
              {error && <ErrBox msg={error} />}
              <Field icon="📧" value={email} onChange={v => { setEmail(v); setError('') }} onEnter={submit} placeholder="your@email.com" label="REGISTERED EMAIL" type="email" />
              <PrimaryBtn onClick={submit} loading={load} label="Send Reset Link" />
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default ForgotPassword
