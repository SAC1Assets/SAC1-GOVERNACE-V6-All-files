/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useNavigate } from 'react-router-dom'
import PriceTicker from '@/components/layout/PriceTicker'

const ROLES = [
  {
    path: '/admin/login',
    icon: '🏛️',
    label: 'Administration',
    desc: 'Full controls — disbursements, compliance, SAC1 transfers, user management & support inbox.',
    cta: 'LOGIN TO ENTER →',
    color: '#6D28D9',
    border: 'rgba(139,92,246,.4)',
    badge: '🔐 AUTH REQUIRED',
    grad: 'linear-gradient(135deg,#6D28D9,#4338CA)',
  },
  {
    path: '/membership',
    icon: '🌍',
    label: 'Get a Governance Seat',
    desc: 'New to SAC1? Choose your governance membership — Community from $100. Own a seat in the economy.',
    cta: 'GET YOUR SEAT →',
    color: '#0F9B8E',
    border: 'rgba(15,155,142,.4)',
    badge: 'GENESIS ROUND OPEN',
    grad: 'linear-gradient(135deg,#0F9B8E,#0F766E)',
  },
  {
    path: '/login',
    icon: '🪙',
    label: 'Token Holder',
    desc: 'Existing member? Log in to your governance dashboard — treasury, proposals, staking, support.',
    cta: 'LOG IN →',
    color: '#059669',
    border: 'rgba(5,150,105,.3)',
    badge: null,
    grad: 'linear-gradient(135deg,#059669,#0F766E)',
  },
]

export default function RoleGate() {
  const navigate = useNavigate()

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg,#EEF2FF,#F5F3FF,#ECFDF5)', fontFamily: 'var(--font-body)', position: 'relative', overflow: 'hidden' }}>
      {/* Decorative blobs */}
      {[
        { s: 320, t: -80, l: -80, c: 'rgba(109,40,217,.18)' },
        { s: 260, t: '60%', r: -100, c: 'rgba(5,150,105,.18)' },
        { s: 200, b: -60, l: '40%', c: 'rgba(37,99,235,.15)' },
      ].map((b, i) => (
        <div key={i} style={{ position: 'absolute', width: b.s, height: b.s, borderRadius: '50%', background: b.c, top: b.t, left: b.l, right: b.r, bottom: b.b, filter: 'blur(40px)', pointerEvents: 'none' }} />
      ))}

      <PriceTicker />

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 'calc(100vh - 42px)', padding: '40px 24px' }}>
        <div style={{ textAlign: 'center', position: 'relative', zIndex: 1, maxWidth: 720, width: '100%' }}>
          {/* Logo */}
          <div style={{ display: 'inline-flex', width: 62, height: 62, borderRadius: 17, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', alignItems: 'center', justifyContent: 'center', marginBottom: 18, boxShadow: 'var(--shadow-sac)' }}>
            <span style={{ fontSize: 26, fontWeight: 900, color: '#fff', fontFamily: 'var(--font-display)' }}>S</span>
          </div>

          <div style={{ fontSize: 9, letterSpacing: '.28em', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', marginBottom: 5 }}>SableAssent Coin Corporation</div>
          <div style={{ fontSize: 42, fontWeight: 900, fontFamily: 'var(--font-display)', marginBottom: 5, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>SAC1 Governance</div>
          <div style={{ fontSize: 14, color: 'var(--text-muted)', fontFamily: 'var(--font-body)', marginBottom: 8 }}>"Own a Seat in the Economy."</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-body)', marginBottom: 30 }}>Select your access role to continue</div>

          {/* Role cards */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginBottom: 14 }}>
            {ROLES.map(r => (
              <div key={r.label} onClick={() => navigate(r.path)}
                style={{ background: '#fff', borderRadius: 15, padding: '22px 16px', cursor: 'pointer', border: `2px solid ${r.border}`, boxShadow: `0 4px 22px ${r.color}12`, textAlign: 'left', position: 'relative', overflow: 'hidden', transition: 'transform .15s' }}
                onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-4px)'}
                onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
              >
                {r.badge && <div style={{ position: 'absolute', top: 9, right: 9, padding: '2px 7px', borderRadius: 7, background: `${r.color}18`, color: r.color, fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 8, letterSpacing: '.1em' }}>{r.badge}</div>}
                <div style={{ width: 40, height: 40, borderRadius: 12, background: r.grad, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 11, fontSize: 19 }}>{r.icon}</div>
                <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', fontFamily: 'var(--font-display)', marginBottom: 5 }}>{r.label}</div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-body)', lineHeight: 1.7, marginBottom: 10 }}>{r.desc}</div>
                <div style={{ fontSize: 10, color: r.color, fontFamily: 'var(--font-mono)', fontWeight: 700 }}>{r.cta}</div>
              </div>
            ))}
          </div>

          {/* Sign up banner */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 11, padding: '14px 18px', borderRadius: 13, background: '#fff', border: '1.5px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}>
            <span style={{ fontSize: 13, color: 'var(--text-muted)', fontFamily: 'var(--font-body)' }}>New to SAC1?</span>
            <button onClick={() => navigate('/signup')}
              style={{ padding: '9px 22px', borderRadius: 10, background: 'linear-gradient(135deg,#0F9B8E,#0F766E)', border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14, cursor: 'pointer', boxShadow: '0 4px 14px rgba(15,155,142,.4)', display: 'flex', alignItems: 'center', gap: 6 }}>
              🌍 Sign Up — Create Account
            </button>
          </div>

          <div style={{ marginTop: 16, fontSize: 9, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '.12em' }}>
            GOVERNANCE PROTOCOL v6.0 · SAC1 (POS) · SABLEASENT COIN CORPORATION · JUNE 2026
          </div>
        </div>
      </div>
    </div>
  )
}
