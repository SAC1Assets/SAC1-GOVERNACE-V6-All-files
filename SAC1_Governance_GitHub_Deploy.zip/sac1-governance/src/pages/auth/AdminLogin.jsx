/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Unauthorized copying or distribution is strictly prohibited.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { BackBtn, Spinner } from '@/components/ui'
import TwoFactorModal from '@/components/modals/TwoFactorModal'

export default function AdminLogin() {
  const navigate = useNavigate()
  const { loginAdmin, verify2FA } = useAuth()
  const [uname, setUname]   = useState('')
  const [pwd,   setPwd]     = useState('')
  const [showP, setShowP]   = useState(false)
  const [error, setError]   = useState('')
  const [attempts, setAtt]  = useState(0)
  const [loading, setLoad]  = useState(false)
  const [shake, setShake]   = useState(false)
  const [step, setStep]     = useState('login')
  const [tfEmail, setTfEmail] = useState('')
  const ref = useRef(null)
  useEffect(() => { ref.current?.focus() }, [])
  const trig = () => { setShake(true); setTimeout(() => setShake(false), 500) }
  const locked = attempts >= 5

  const handleLogin = async () => {
    if (!uname || !pwd) { setError('Enter both fields.'); trig(); return }
    if (locked) return
    setLoad(true); setError('')
    try {
      const res = await loginAdmin(uname.trim(), pwd)
      if (res.requires2FA) { setTfEmail(res.email); setStep('2fa') }
      else navigate('/admin/treasury')
    } catch (err) {
      const rem = 4 - attempts
      setAtt(a => a + 1)
      setError(attempts >= 4 ? 'Account locked. Contact administrator.' : `Wrong credentials. ${rem} attempt${rem !== 1 ? 's' : ''} remaining.`)
      setPwd(''); trig()
    } finally { setLoad(false) }
  }

  const handle2FA = async (code) => {
    await verify2FA(code)
    navigate('/admin/treasury')
  }

  if (step === '2fa') return <TwoFactorModal email={tfEmail} onSuccess={handle2FA} onBack={() => setStep('login')} dark />

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(150deg,#0A0C1E,#1A0F3C,#0C1A2E)', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' }}>
      {[
        { w: 400, t: '-10%', l: '-8%', c: 'rgba(109,40,217,.25)', b: 80 },
        { w: 300, t: '55%',  r: '-5%', c: 'rgba(67,56,202,.2)',   b: 70 },
      ].map((o, i) => (
        <div key={i} style={{ position: 'absolute', width: o.w, height: o.w, borderRadius: '50%', background: o.c, top: o.t, left: o.l, right: o.r, filter: `blur(${o.b}px)`, pointerEvents: 'none' }} />
      ))}
      <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(109,40,217,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(109,40,217,.04) 1px,transparent 1px)', backgroundSize: '44px 44px' }} />

      <div style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: 420, padding: '0 22px' }}>
        <div style={{ marginBottom: 26 }}><BackBtn onClick={() => navigate('/')} label="Back" dark /></div>

        <div style={{ background: 'rgba(255,255,255,.04)', backdropFilter: 'blur(22px)', borderRadius: 22, border: '1px solid rgba(255,255,255,.11)', padding: '36px 32px', boxShadow: '0 30px 80px rgba(0,0,0,.5)', animation: shake ? 'shake .4s ease' : 'slideIn .3s ease' }}>

          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 22 }}>
            <div style={{ position: 'relative' }}>
              <div style={{ width: 60, height: 60, borderRadius: 16, background: 'linear-gradient(135deg,var(--sac),var(--indigo))', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 8px 30px rgba(109,40,217,.6)' }}>
                <span style={{ fontSize: 24, fontWeight: 900, color: '#fff', fontFamily: 'var(--font-display)' }}>S</span>
              </div>
              <div style={{ position: 'absolute', top: -3, right: -3, width: 18, height: 18, borderRadius: '50%', background: 'linear-gradient(135deg,#B45309,#D97706)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, border: '2px solid rgba(10,12,30,.8)' }}>🔐</div>
            </div>
          </div>

          <div style={{ textAlign: 'center', marginBottom: 24 }}>
            <div style={{ fontSize: 22, fontWeight: 900, color: '#fff', fontFamily: 'var(--font-display)', marginBottom: 5 }}>Admin Access</div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,.4)', fontFamily: 'var(--font-mono)', letterSpacing: '.12em' }}>SAC1 GOVERNANCE · SABLEASENT</div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 12px', borderRadius: 9, background: 'rgba(109,40,217,.12)', border: '1px solid rgba(109,40,217,.25)', marginBottom: 20 }}>
            <span style={{ fontSize: 13 }}>🛡️</span>
            <span style={{ fontSize: 10, color: 'rgba(255,255,255,.5)', fontFamily: 'var(--font-mono)', lineHeight: 1.6 }}>Restricted — All access logged. 2FA required.</span>
          </div>

          {error && <div style={{ display: 'flex', gap: 7, padding: '9px 12px', borderRadius: 9, background: 'rgba(220,38,38,.18)', border: '1px solid rgba(220,38,38,.4)', marginBottom: 14 }}><span>⚠️</span><span style={{ fontSize: 11, color: '#FCA5A5', fontFamily: 'var(--font-mono)' }}>{error}</span></div>}

          <div style={{ marginBottom: 12 }}>
            <label style={{ display: 'block', fontSize: 9, color: 'rgba(255,255,255,.4)', fontFamily: 'var(--font-mono)', letterSpacing: '.14em', marginBottom: 5 }}>USERNAME</label>
            <div style={{ position: 'relative' }}>
              <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 13, opacity: .35 }}>👤</span>
              <input ref={ref} value={uname} onChange={e => { setUname(e.target.value); setError('') }} onKeyDown={e => e.key === 'Enter' && !locked && handleLogin()} disabled={locked} placeholder="Username"
                style={{ width: '100%', padding: '12px 12px 12px 38px', borderRadius: 11, background: 'rgba(255,255,255,.07)', border: '1.5px solid rgba(255,255,255,.13)', fontSize: 13, fontFamily: 'var(--font-body)', color: '#fff', boxSizing: 'border-box', opacity: locked ? .5 : 1 }} />
            </div>
          </div>

          <div style={{ marginBottom: 18 }}>
            <label style={{ display: 'block', fontSize: 9, color: 'rgba(255,255,255,.4)', fontFamily: 'var(--font-mono)', letterSpacing: '.14em', marginBottom: 5 }}>PASSWORD</label>
            <div style={{ position: 'relative' }}>
              <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 13, opacity: .35 }}>🔑</span>
              <input value={pwd} onChange={e => { setPwd(e.target.value); setError('') }} onKeyDown={e => e.key === 'Enter' && !locked && handleLogin()} disabled={locked} type={showP ? 'text' : 'password'} placeholder="Password"
                style={{ width: '100%', padding: '12px 40px 12px 38px', borderRadius: 11, background: 'rgba(255,255,255,.07)', border: '1.5px solid rgba(255,255,255,.13)', fontSize: 13, fontFamily: 'var(--font-body)', color: '#fff', boxSizing: 'border-box', opacity: locked ? .5 : 1 }} />
              <button onClick={() => setShowP(p => !p)} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, opacity: .4, padding: 0 }}>{showP ? '🙈' : '👁️'}</button>
            </div>
          </div>

          {attempts > 0 && attempts < 5 && (
            <div style={{ display: 'flex', gap: 5, justifyContent: 'center', marginBottom: 13 }}>
              {Array.from({ length: 5 }).map((_, i) => <div key={i} style={{ width: 26, height: 3, borderRadius: 2, background: i < attempts ? 'var(--red)' : 'rgba(255,255,255,.12)', transition: 'background .3s' }} />)}
            </div>
          )}

          <button onClick={handleLogin} disabled={locked || loading}
            style={{ width: '100%', padding: '13px', borderRadius: 12, background: locked ? 'rgba(255,255,255,.08)' : 'linear-gradient(135deg,var(--sac),var(--indigo))', border: 'none', color: locked ? 'rgba(255,255,255,.3)' : '#fff', fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 14, cursor: locked ? 'not-allowed' : 'pointer', boxShadow: locked ? 'none' : 'var(--shadow-sac)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            {loading ? <><Spinner />Authenticating…</> : locked ? '🔒 Locked' : 'Log In → Verify 2FA'}
          </button>

          <div style={{ marginTop: 16, textAlign: 'center', fontSize: 9, color: 'rgba(255,255,255,.18)', fontFamily: 'var(--font-mono)' }}>Demo: sac1admin / SableAssent@2026</div>
        </div>
      </div>
    </div>
  )
}
