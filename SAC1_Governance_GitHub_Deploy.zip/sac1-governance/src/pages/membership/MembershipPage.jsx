/*
 * Copyright (c) 2026 SableAssent Coin Corporation. All rights reserved.
 * Admin@SableAssent.com · www.SableAssent.com
 */
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { GOVERNANCE_TIERS, LOCK_PERIODS } from '@/constants'
import { PaymentModal } from '@/components/modals/Modals'
import PriceTicker from '@/components/layout/PriceTicker'
import { Bar } from '@/components/ui'
import { usePrices } from '@/context/PriceContext'

export default function MembershipPage() {
  const navigate = useNavigate()
  const { sac1 } = usePrices()
  const [sel,      setSel]     = useState(null)
  const [showPay,  setShowPay] = useState(false)

  const totalSeats = GOVERNANCE_TIERS.reduce((a,t)=>a+t.seatsTotal, 0)
  const taken      = GOVERNANCE_TIERS.reduce((a,t)=>a+(t.seatsTotal - Math.floor(t.seatsTotal * 0.72)), 0)

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg)', fontFamily:'var(--font-body)' }}>
      {showPay && sel && (
        <PaymentModal
          tier={sel}
          onClose={() => setShowPay(false)}
          onLogin={() => navigate('/login')}
        />
      )}

      <PriceTicker />

      {/* Hero */}
      <div style={{ background:'linear-gradient(150deg,#0A0C1E,#1A0F3C,#0C1A2E)', padding:'52px 36px 44px', textAlign:'center', position:'relative', overflow:'hidden' }}>
        {[{s:360,t:'-12%',l:'-5%',c:'rgba(109,40,217,.26)'},{s:260,t:'55%',r:'-4%',c:'rgba(37,99,235,.2)'}].map((o,i)=>(
          <div key={i} style={{ position:'absolute', width:o.s, height:o.s, borderRadius:'50%', background:o.c, top:o.t, left:o.l, right:o.r, filter:'blur(55px)', pointerEvents:'none' }}/>
        ))}
        <div style={{ position:'absolute', inset:0, backgroundImage:'linear-gradient(rgba(109,40,217,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(109,40,217,.04) 1px,transparent 1px)', backgroundSize:'44px 44px' }}/>
        <div style={{ position:'relative', zIndex:1 }}>
          <div style={{ display:'flex', justifyContent:'flex-start', marginBottom:24 }}>
            <button onClick={() => navigate('/')} style={{ display:'inline-flex', alignItems:'center', gap:7, padding:'9px 18px', borderRadius:11, background:'rgba(255,255,255,.14)', border:'2px solid rgba(255,255,255,.38)', color:'#fff', fontFamily:'var(--font-display)', fontWeight:900, fontSize:13, cursor:'pointer' }}>
              ← Back
            </button>
          </div>
          <div style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'6px 14px', borderRadius:20, background:'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.14)', marginBottom:18 }}>
            <div style={{ width:7, height:7, borderRadius:'50%', background:'#6EE7B7', animation:'blink 1.5s infinite' }}/>
            <span style={{ fontSize:11, color:'rgba(255,255,255,.7)', fontFamily:'var(--font-mono)', letterSpacing:'.1em' }}>GENESIS ROUND OPEN — {totalSeats - taken} of {totalSeats} seats remaining</span>
          </div>
          <div style={{ fontSize:10, color:'#8B5CF6', fontFamily:'var(--font-mono)', letterSpacing:'.2em', marginBottom:10, textTransform:'uppercase' }}>SableAssent Coin Corporation · SAC1 Digital Governance</div>
          <h1 style={{ fontSize:52, fontWeight:900, color:'#fff', fontFamily:'var(--font-display)', lineHeight:1.12, margin:'0 0 13px' }}>
            Get a<br/>
            <span style={{ background:'linear-gradient(135deg,#A78BFA,#60A5FA)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>Governance Seat.</span>
          </h1>
          <p style={{ fontSize:15, color:'rgba(255,255,255,.6)', fontFamily:'var(--font-body)', lineHeight:1.75, maxWidth:520, margin:'0 auto 26px' }}>
            Africa's Digital Governance Membership. Community from <strong style={{ color:'rgba(255,255,255,.9)' }}>$100</strong>.
            Treasury voting, ecosystem participation, fractional economic ownership.
          </p>
          <div style={{ display:'flex', gap:11, justifyContent:'center', flexWrap:'wrap' }}>
            <button onClick={() => document.getElementById('tiers')?.scrollIntoView({ behavior:'smooth' })}
              style={{ padding:'13px 26px', borderRadius:11, background:'linear-gradient(135deg,var(--sac),var(--indigo))', border:'none', color:'#fff', fontFamily:'var(--font-display)', fontWeight:800, fontSize:14, cursor:'pointer', boxShadow:'0 6px 22px rgba(109,40,217,.5)' }}>
              Get a Governance Seat →
            </button>
            <button onClick={() => navigate('/login')}
              style={{ padding:'13px 26px', borderRadius:11, background:'rgba(255,255,255,.07)', border:'1.5px solid rgba(255,255,255,.18)', color:'rgba(255,255,255,.85)', fontFamily:'var(--font-display)', fontWeight:600, fontSize:14, cursor:'pointer' }}>
              Already a member? Log In
            </button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth:1160, margin:'0 auto', padding:'40px 24px' }}>

        {/* Utility pillars */}
        <div style={{ textAlign:'center', marginBottom:24 }}>
          <div style={{ fontSize:10, color:'var(--sac)', fontFamily:'var(--font-mono)', letterSpacing:'.2em', marginBottom:8, textTransform:'uppercase' }}>What You Actually Own</div>
          <h2 style={{ fontSize:26, fontWeight:900, color:'var(--text)', fontFamily:'var(--font-display)', margin:0 }}>6 Governance Rights. One Membership.</h2>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:13, marginBottom:48 }}>
          {[
            { icon:'🗳️', title:'Governance Rights',    desc:'Vote on treasury, partnerships, grants, liquidity, and ecosystem upgrades — on-chain.' },
            { icon:'🏛️', title:'Community Seat',       desc:'Every SAC1 = a voice. You are a governance participant, not a customer.' },
            { icon:'💰', title:'Treasury Participation',desc:'Help direct the Community Treasury. Vote on capital allocation decisions.' },
            { icon:'⚡', title:'Validator Participation',desc:'Stake SAC1 to secure the PoS network and increase governance weight up to 3x.' },
            { icon:'📊', title:'Reputation Layer',      desc:'Build a Governance Reputation Score from participation, votes, and proposals.' },
            { icon:'🤝', title:'Delegated Voting',      desc:'Assign your voting weight to a trusted member when you cannot participate.' },
          ].map(u => (
            <div key={u.title} style={{ background:'var(--panel)', borderRadius:16, border:'1.5px solid var(--border)', padding:22, boxShadow:'var(--shadow-sm)' }}>
              <div style={{ fontSize:26, marginBottom:9 }}>{u.icon}</div>
              <div style={{ fontSize:14, fontWeight:700, color:'var(--text)', fontFamily:'var(--font-display)', marginBottom:6 }}>{u.title}</div>
              <div style={{ fontSize:11, color:'var(--text-muted)', fontFamily:'var(--font-body)', lineHeight:1.7 }}>{u.desc}</div>
            </div>
          ))}
        </div>

        {/* Tier cards */}
        <div id="tiers" style={{ textAlign:'center', marginBottom:22 }}>
          <div style={{ fontSize:10, color:'var(--sac)', fontFamily:'var(--font-mono)', letterSpacing:'.2em', marginBottom:8, textTransform:'uppercase' }}>Choose Your Governance Seat — Genesis Round</div>
          <h2 style={{ fontSize:26, fontWeight:900, color:'var(--text)', fontFamily:'var(--font-display)', margin:'0 0 6px' }}>Get a Governance Seat</h2>
          <p style={{ fontSize:12, color:'var(--text-muted)', fontFamily:'var(--font-body)', margin:0 }}>Community from $100 · Phase 1 closes June 30, 2026</p>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:13, marginBottom:32 }}>
          {GOVERNANCE_TIERS.map(tier => {
            const left = Math.floor(tier.seatsTotal * 0.28)
            const pct  = ((tier.seatsTotal - left) / tier.seatsTotal) * 100
            const isSel = sel?.id === tier.id
            return (
              <div key={tier.id} onClick={() => setSel(tier)}
                style={{ background:'var(--panel)', borderRadius:15, border:`2px solid ${isSel?tier.color:'var(--border)'}`, padding:'19px 15px', cursor:'pointer', position:'relative', boxShadow: isSel?`0 8px 28px ${tier.color}22`:'var(--shadow-sm)', transition:'all .2s' }}>
                {tier.badge && (
                  <div style={{ position:'absolute', top:-10, left:'50%', transform:'translateX(-50%)', padding:'2px 9px', borderRadius:10, background:tier.color, fontSize:9, color:'#fff', fontFamily:'var(--font-mono)', fontWeight:700, whiteSpace:'nowrap' }}>{tier.badge}</div>
                )}
                <div style={{ width:36, height:36, borderRadius:10, background:`linear-gradient(135deg,${tier.color},${tier.color}90)`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, marginBottom:9 }}>{tier.icon}</div>
                <div style={{ fontSize:13, fontWeight:800, color:'var(--text)', fontFamily:'var(--font-display)', marginBottom:2 }}>{tier.name}</div>
                <div style={{ fontSize:20, fontWeight:900, color:tier.color, fontFamily:'var(--font-mono)', marginBottom:1 }}>{tier.price}</div>
                <div style={{ fontSize:9, color:'var(--text-muted)', fontFamily:'var(--font-mono)', marginBottom:8 }}>or {tier.annual}</div>
                <div style={{ padding:'5px 9px', borderRadius:7, background:`${tier.color}12`, border:`1px solid ${tier.color}25`, marginBottom:9 }}>
                  <div style={{ fontSize:9, fontWeight:700, color:tier.color, fontFamily:'var(--font-mono)' }}>🎁 {tier.sac1Grant}</div>
                </div>
                <div style={{ display:'flex', alignItems:'center', gap:5, marginBottom:10 }}>
                  <span style={{ fontSize:9, color:'var(--text-muted)', fontFamily:'var(--font-mono)' }}>Weight:</span>
                  <span style={{ fontSize:14, fontWeight:900, color:tier.color, fontFamily:'var(--font-mono)' }}>{tier.weight}</span>
                </div>
                {tier.features.slice(0,4).map((f,i) => (
                  <div key={i} style={{ display:'flex', gap:5, padding:'3px 0', borderBottom: i<3?'1px solid var(--border)':'none' }}>
                    <span style={{ color:'var(--green)', fontSize:9, flexShrink:0 }}>✓</span>
                    <span style={{ fontSize:10, color:'var(--text-med)', fontFamily:'var(--font-body)' }}>{f}</span>
                  </div>
                ))}
                {tier.features.length > 4 && (
                  <div style={{ fontSize:9, color:tier.color, fontFamily:'var(--font-body)', marginTop:5, fontWeight:600 }}>+{tier.features.length-4} more →</div>
                )}
                <div style={{ marginTop:10, paddingTop:8, borderTop:'1px solid var(--border)' }}>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
                    <span style={{ fontSize:8, color:'var(--text-muted)', fontFamily:'var(--font-mono)' }}>{left} left</span>
                    <span style={{ fontSize:8, color:tier.color, fontFamily:'var(--font-mono)', fontWeight:700 }}>{Math.round(pct)}% filled</span>
                  </div>
                  <Bar pct={pct} color={tier.color} h={3} />
                </div>
                <button onClick={e => { e.stopPropagation(); setSel(tier); setShowPay(true) }}
                  style={{ width:'100%', marginTop:10, padding:'9px', borderRadius:10, background: isSel?`linear-gradient(135deg,${tier.color},${tier.color}cc)`:`${tier.color}12`, border:`1.5px solid ${tier.color}40`, color: isSel?'#fff':tier.color, fontFamily:'var(--font-display)', fontWeight:800, fontSize:12, cursor:'pointer', transition:'all .15s' }}>
                  {isSel ? '✓ Select This Seat →' : 'Select This Seat'}
                </button>
              </div>
            )
          })}
        </div>

        {/* Lock periods */}
        <div style={{ background:'var(--panel)', borderRadius:16, border:'1.5px solid var(--border)', padding:22, boxShadow:'var(--shadow-sm)', marginBottom:22 }}>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 2fr', gap:22, alignItems:'start' }}>
            <div>
              <div style={{ fontSize:10, letterSpacing:'.2em', color:'var(--sac)', textTransform:'uppercase', fontFamily:'var(--font-mono)', fontWeight:700, marginBottom:14 }}>Locked Governance Mechanics</div>
              <div style={{ fontSize:18, fontWeight:800, color:'var(--text)', fontFamily:'var(--font-display)', marginBottom:8 }}>Stake longer.<br/>Govern stronger.</div>
              <div style={{ fontSize:12, color:'var(--text-muted)', fontFamily:'var(--font-body)', lineHeight:1.7 }}>Lock SAC1 to increase voting weight. Long-term commitment = greater ecosystem influence.</div>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:8 }}>
              {LOCK_PERIODS.map(lp => (
                <div key={lp.label} style={{ textAlign:'center', padding:'12px 7px', borderRadius:10, background:`${lp.color}10`, border:`1.5px solid ${lp.color}25` }}>
                  <div style={{ fontSize:18, fontWeight:900, color:lp.color, fontFamily:'var(--font-mono)', marginBottom:3 }}>{lp.display}</div>
                  <div style={{ fontSize:10, fontWeight:700, color:'var(--text)', fontFamily:'var(--font-display)', marginBottom:2 }}>{lp.label}</div>
                  <div style={{ fontSize:8, color:'var(--text-muted)', fontFamily:'var(--font-mono)' }}>multiplier</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{ padding:'11px 16px', borderRadius:10, background:'var(--bg-alt)', border:'1px solid var(--border)', marginBottom:22, fontSize:9, color:'var(--text-muted)', fontFamily:'var(--font-mono)', lineHeight:1.8 }}>
          ⚖️ SAC1 is a governance participation token. Membership grants governance rights — not investment returns. Review our Governance Participation Agreement before purchasing.
        </div>

        <div style={{ display:'flex', justifyContent:'center', gap:11 }}>
          <button onClick={() => navigate('/login')} style={{ padding:'10px 20px', borderRadius:11, background:'var(--bg-alt)', border:'1.5px solid var(--border)', color:'var(--text-muted)', fontFamily:'var(--font-body)', fontWeight:600, fontSize:13, cursor:'pointer' }}>
            Already a member? Log In →
          </button>
          <button onClick={() => navigate('/signup')} style={{ padding:'10px 20px', borderRadius:11, background:'linear-gradient(135deg,var(--sac),var(--indigo))', border:'none', color:'#fff', fontFamily:'var(--font-display)', fontWeight:700, fontSize:13, cursor:'pointer', boxShadow:'var(--shadow-sac)' }}>
            Create Account — Sign Up →
          </button>
        </div>
      </div>
    </div>
  )
}
