# SAC1 Governance Platform — Frontend

**SableAssent Coin Corporation** | Digital Governance Membership Platform

[![React](https://img.shields.io/badge/React-18.2-61DAFB?logo=react)](https://react.dev)
[![Vite](https://img.shields.io/badge/Vite-5.1-646CFF?logo=vite)](https://vitejs.dev)
[![License](https://img.shields.io/badge/License-Proprietary-red)](./LICENSE)

> **SAC1 is a governance participation token — not an investment product.**
> Membership grants voting rights, treasury participation, and ecosystem access only.

---

## Overview

The SAC1 Governance Platform frontend is a production-grade React 18 application for the SableAssent Coin Corporation governance membership system. It provides:

- **Role-gated access** — Administration, Token Holder, and Public Membership paths
- **Four governance tiers** — Community, Governance, Treasury Council, Founding Partner
- **Live price ticker** — SAC1/USD and USDC real-time prices
- **Full governance dashboard** — Treasury, Compliance, Voting, Staking, Support tabs
- **Admin portal** — User management, disbursements, compliance toggles, support inbox
- **2FA authentication** — 6-digit OTP via email, mandatory for all logins
- **Wallet integration** — MetaMask, WalletConnect, Coinbase Wallet, Phantom

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | React 18.2 + Vite 5.1 |
| Routing | React Router DOM v6 |
| State | Zustand + React Query (TanStack) |
| HTTP | Axios with auto-refresh interceptor |
| Styling | CSS Variables + inline styles (no Tailwind) |
| Fonts | Google Fonts: Outfit + Space Grotesk + Space Mono |
| Notifications | react-hot-toast |
| Charts | Recharts |
| Animation | Framer Motion |

---

## Project Structure

```
sac1-governance/
├── public/
│   └── favicon.svg
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── DashboardHeader.jsx   # Top header — wallet, user, logout
│   │   │   ├── PriceTicker.jsx       # Scrolling live price banner
│   │   │   └── Sidebar.jsx           # Left nav — role-aware
│   │   ├── modals/
│   │   │   ├── TwoFactorModal.jsx    # 2FA OTP modal (shared)
│   │   │   └── Modals.jsx            # WalletModal, SendSAC1Modal,
│   │   │                             #   PaymentModal, ChatPanel
│   │   └── ui/
│   │       └── index.jsx             # Spark, Bar, Tag, Pill, Card,
│   │                                 #   STitle, Spinner, BackBtn,
│   │                                 #   Toggle, LiveDot, TierBadge
│   ├── constants/
│   │   └── index.js                  # Tiers, lock periods, API endpoints
│   ├── context/
│   │   ├── AuthContext.jsx           # JWT auth + role state
│   │   └── PriceContext.jsx          # Live price feed
│   ├── hooks/
│   │   ├── useGovernance.js          # Proposals + voting
│   │   ├── useSupport.js             # Tickets
│   │   ├── useTreasury.js            # Treasury overview + disbursements
│   │   └── useUsers.js               # Admin user management
│   ├── pages/
│   │   ├── auth/
│   │   │   ├── RoleGate.jsx          # Landing role selector
│   │   │   ├── SignUpPage.jsx        # Member registration
│   │   │   ├── HolderLogin.jsx       # Token holder login
│   │   │   ├── AdminLogin.jsx        # Admin login (dark theme)
│   │   │   ├── TwoFactorPage.jsx     # Standalone 2FA route
│   │   │   └── ForgotPassword.jsx    # Password reset
│   │   ├── dashboard/
│   │   │   ├── DashboardLayout.jsx   # Tab nav + outlet wrapper
│   │   │   ├── TreasuryTab.jsx       # Treasury KPIs + rules
│   │   │   ├── ComplianceTab.jsx     # Compliance rules toggle
│   │   │   ├── VotingTab.jsx         # Proposals + voting
│   │   │   ├── SupportTab.jsx        # Ticket system
│   │   │   └── StakingTab.jsx        # SAC1 staking
│   │   ├── admin/
│   │   │   ├── AdminLayout.jsx       # Admin tab nav + outlet
│   │   │   └── AdminUsersTab.jsx     # User spreadsheet + SAC1 send
│   │   └── membership/
│   │       └── MembershipPage.jsx    # Tier cards + payment modal
│   ├── services/
│   │   ├── api.js                    # Axios instance + interceptors
│   │   ├── auth.service.js
│   │   ├── governance.service.js
│   │   └── membership.service.js
│   ├── styles/
│   │   └── globals.css               # CSS variables + animations
│   ├── utils/
│   │   └── index.js                  # Formatters, calculators, helpers
│   ├── App.jsx                       # Root router + protected routes
│   └── main.jsx                      # React entry point
├── index.html
├── vite.config.js                    # Vite config + /api proxy
├── package.json
├── .gitignore
├── .env.example                      # Environment variable template
└── LICENSE
```

---

## Quick Start

### Prerequisites
- Node.js 18+ (LTS recommended)
- npm 9+ or pnpm 8+
- Backend API running at `localhost:8000` (see [sac1-backend](../sac1-backend))

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/SableAssent/sac1-governance.git
cd sac1-governance

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.example .env
# Edit .env — the default VITE_API_URL=http://localhost:8000/api/v1
# works out of the box with the Vite dev proxy

# 4. Start development server
npm run dev
# App runs at http://localhost:3000
```

### With Backend (Full Stack via Docker)

```bash
# From the sac1-backend directory:
docker-compose up -d

# Then start the frontend separately:
cd ../sac1-governance && npm run dev
```

---

## Available Scripts

```bash
npm run dev       # Start Vite dev server (port 3000, hot reload)
npm run build     # Production build → dist/
npm run preview   # Preview production build locally
npm run lint      # ESLint check
```

---

## Routing Structure

```
/                           RoleGate         (public)
/signup                     SignUpPage        (public)
/login                      HolderLogin       (public)
/admin/login                AdminLogin        (public)
/2fa                        TwoFactorPage     (public)
/forgot                     ForgotPassword    (public)
/membership                 MembershipPage    (public)

/dashboard/                 DashboardLayout   (requires auth: holder)
  treasury                  TreasuryTab
  compliance                ComplianceTab
  voting                    VotingTab
  support                   SupportTab
  staking                   StakingTab

/admin/                     AdminLayout       (requires auth: admin)
  treasury                  TreasuryTab (admin mode)
  compliance                ComplianceTab (admin mode)
  voting                    VotingTab (admin mode)
  support                   SupportTab (admin mode)
  users                     AdminUsersTab
```

---

## Authentication Flow

1. User selects role on RoleGate (`/`)
2. Enters credentials → `POST /api/v1/auth/login`
3. Backend returns `pre_auth_token` + triggers 2FA email
4. User enters 6-digit OTP → `POST /api/v1/auth/verify-2fa`
5. Backend returns `access_token` (30min) + `refresh_token` (7 days)
6. Tokens stored in `localStorage`; Axios interceptor auto-refreshes on 401

### Demo Credentials (Development Only)

```
Token Holder:  amara_osei / Demo@1234
Admin:         sac1admin  / SableAssent@2026
2FA Code:      123456  (demo shortcut — backend validates this in dev mode)
```

---

## API Integration

The frontend talks to the FastAPI backend via Axios. In development, Vite proxies all `/api` requests:

```
Frontend (localhost:3000) → Vite proxy /api → Backend (localhost:8000)
```

All API constants are in `src/constants/index.js`. All HTTP calls go through `src/services/api.js`.

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `VITE_API_URL` | Yes | Backend API base URL |
| `VITE_APP_NAME` | No | Display name |
| `VITE_STRIPE_PUBLISHABLE_KEY` | Production | Stripe.js public key |
| `VITE_COINBASE_APP_ID` | Production | Coinbase Commerce app |
| `VITE_ENABLE_WALLET_CONNECT` | No | Toggle wallet connect |
| `VITE_MAINTENANCE_MODE` | No | Show maintenance banner |

---

## Deployment

### Vercel (Recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Set environment variables in Vercel dashboard:
# VITE_API_URL=https://api.sableassent.com/api/v1
# VITE_STRIPE_PUBLISHABLE_KEY=pk_live_xxx
```

### AWS S3 + CloudFront

```bash
# Build
npm run build

# Upload dist/ to S3
aws s3 sync dist/ s3://app.sableassent.com --delete

# Invalidate CloudFront
aws cloudfront create-invalidation \
  --distribution-id YOUR_CF_ID \
  --paths "/*"
```

### Dockerfile

```dockerfile
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
```

---

## Governance Tiers

| Tier | Price | SAC1 Grant | Gov. Weight |
|---|---|---|---|
| Community Member | $100 | 1,000–2,500 | 1x |
| Governance Member | $500 | 5,000–25,000 | 1.5x |
| Treasury Council | $5,000 | 50,000–250,000 | 2x |
| Founding Gov. Partner | $50,000+ | 500,000+ | 3x |

**Lock Period Multipliers:** No Lock=1x · 3mo=1.25x · 6mo=1.5x · 12mo=2x · 24mo=3x

---

## Legal

```
Copyright (c) 2026 SableAssent Coin Corporation. All Rights Reserved.
Unauthorized copying, distribution, modification, or use is strictly prohibited.
SAC1 is a governance participation token — not an investment product.
```

**Contact:** Admin@SableAssent.com · www.SableAssent.com

---

## Contributing

This is a proprietary codebase. External contributions are not accepted without a signed Contributor License Agreement from SableAssent Coin Corporation.
