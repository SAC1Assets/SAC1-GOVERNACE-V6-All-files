// ─────────────────────────────────────────────────────────────────────────────
// SableAssent Pay — Edge Middleware
// Rate limiting + request validation on API routes
// Runs on Vercel Edge Runtime (zero cold starts)
// ─────────────────────────────────────────────────────────────────────────────

import { NextResponse } from 'next/server';

// ── In-memory rate limit store (per Edge worker instance) ────────────────────
// For production at scale, swap this for Vercel KV or Upstash Redis
const rateLimitMap = new Map();

const RATE_LIMITS = {
  '/api/create-payment': { windowMs: 60_000, maxRequests: 10  }, // 10 per minute
  '/api/capture-payment': { windowMs: 60_000, maxRequests: 10  },
  '/api/log-transaction': { windowMs: 60_000, maxRequests: 20  },
  'default':              { windowMs: 60_000, maxRequests: 100 },
};

function getRateLimit(pathname) {
  return RATE_LIMITS[pathname] ?? RATE_LIMITS['default'];
}

function checkRateLimit(key, limit) {
  const now = Date.now();
  const entry = rateLimitMap.get(key) ?? { count: 0, resetAt: now + limit.windowMs };

  // Reset window if expired
  if (now > entry.resetAt) {
    entry.count   = 0;
    entry.resetAt = now + limit.windowMs;
  }

  entry.count++;
  rateLimitMap.set(key, entry);

  return {
    allowed:    entry.count <= limit.maxRequests,
    remaining:  Math.max(0, limit.maxRequests - entry.count),
    resetAt:    entry.resetAt,
  };
}

export function middleware(request) {
  const { pathname } = request.nextUrl;
  const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim()
           ?? request.headers.get('x-real-ip')
           ?? 'unknown';

  // ── Only apply rate limiting to API routes ────────────────────────────────
  if (pathname.startsWith('/api/')) {
    const limit  = getRateLimit(pathname);
    const key    = `${ip}:${pathname}`;
    const result = checkRateLimit(key, limit);

    if (!result.allowed) {
      console.warn(`[RateLimit] BLOCKED ${ip} on ${pathname}`);
      return new NextResponse(
        JSON.stringify({
          error: 'Too many requests. Please wait before trying again.',
          retryAfter: Math.ceil((result.resetAt - Date.now()) / 1000),
        }),
        {
          status: 429,
          headers: {
            'Content-Type':      'application/json',
            'Retry-After':       String(Math.ceil((result.resetAt - Date.now()) / 1000)),
            'X-RateLimit-Limit': String(limit.maxRequests),
            'X-RateLimit-Remaining': String(result.remaining),
          },
        }
      );
    }

    // ── Block obviously malicious payloads ────────────────────────────────
    const userAgent = request.headers.get('user-agent') ?? '';
    if (!userAgent || userAgent.length < 5) {
      return new NextResponse(
        JSON.stringify({ error: 'Request blocked' }),
        { status: 403, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // ── Add rate limit headers to allowed responses ───────────────────────
    const response = NextResponse.next();
    response.headers.set('X-RateLimit-Limit',     String(limit.maxRequests));
    response.headers.set('X-RateLimit-Remaining', String(result.remaining));
    return response;
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/api/:path*'],
};
