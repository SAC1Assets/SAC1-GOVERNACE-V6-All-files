/** @type {import('next').NextConfig} */

const securityHeaders = [
  // ── Force HTTPS for 2 years, include subdomains ──────────────────────────
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload',
  },
  // ── Prevent clickjacking — only allow framing from same origin ────────────
  {
    key: 'X-Frame-Options',
    value: 'SAMEORIGIN',
  },
  // ── Stop browsers from MIME-sniffing ─────────────────────────────────────
  {
    key: 'X-Content-Type-Options',
    value: 'nosniff',
  },
  // ── Referrer policy — don't leak full URL to third parties ───────────────
  {
    key: 'Referrer-Policy',
    value: 'strict-origin-when-cross-origin',
  },
  // ── Disable FLoC / restrict browser features ─────────────────────────────
  {
    key: 'Permissions-Policy',
    value: 'camera=(), microphone=(), geolocation=(), interest-cohort=()',
  },
  // ── Content Security Policy ───────────────────────────────────────────────
  // Allows: same origin, PayPal JS SDK, Stripe JS, Google Fonts, QR lib CDN
  // Blocks: inline scripts (except PayPal/Stripe require nonce — use unsafe-inline
  //         only for trusted payment SDKs), eval, all other origins
  {
    key: 'Content-Security-Policy',
    value: [
      "default-src 'self'",
      // Scripts: self + PayPal SDK + Stripe JS
      "script-src 'self' 'unsafe-inline' https://www.paypal.com https://js.stripe.com https://cdnjs.cloudflare.com",
      // Styles: self + Google Fonts + inline styles (needed for payment widgets)
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      // Fonts
      "font-src 'self' https://fonts.gstatic.com",
      // Images: self + data URIs (for QR codes) + PayPal/Stripe CDNs
      "img-src 'self' data: https://*.paypal.com https://*.stripe.com https://*.paypalobjects.com",
      // Frames: PayPal and Stripe require iframes
      "frame-src https://www.paypal.com https://js.stripe.com https://hooks.stripe.com https://*.privy.io https://auth.privy.io",
      // Connect: API calls to Base44, PayPal, Stripe, Polygon RPC
      "connect-src 'self' https://app.base44.com https://api-m.paypal.com https://api.stripe.com "
      + "https://rpc-mainnet.matic.network https://polygon-rpc.com "
      + "https://auth.privy.io https://*.privy.io https://api.privy.io ",
      // Everything else blocked
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "upgrade-insecure-requests",
    ].join('; '),
  },
  // ── Cross-Origin policies ─────────────────────────────────────────────────
  {
    key: 'Cross-Origin-Opener-Policy',
    value: 'same-origin-allow-popups', // PayPal popup flow requires allow-popups
  },
  {
    key: 'Cross-Origin-Resource-Policy',
    value: 'same-origin',
  },
  // ── Remove server fingerprint ─────────────────────────────────────────────
  {
    key: 'X-Powered-By',
    value: '',
  },
];

const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,

  async headers() {
    return [
      {
        // Apply security headers to ALL routes
        source: '/(.*)',
        headers: securityHeaders,
      },
    ];
  },

  // ── Rate limiting note ────────────────────────────────────────────────────
  // Vercel's built-in DDoS protection handles L3/L4.
  // For L7 rate limiting on /api/* routes, add Vercel's WAF (Pro plan)
  // or use the middleware.js file below.
};

module.exports = nextConfig;
